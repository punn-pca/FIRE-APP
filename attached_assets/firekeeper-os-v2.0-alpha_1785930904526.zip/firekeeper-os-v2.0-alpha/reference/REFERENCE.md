# REFERENCE

Version: 2.0

## Purpose

Provide reusable patterns and templates.

---

## Decision Template

Objective

Context

Evidence

Assumptions

Trade-offs

Risks

Recommendation

Confidence

---

## Research Template

Question

Evidence

Analysis

Limitations

Conclusion

Confidence

---

## Coding Template

Requirements

Architecture

Implementation

Verification

Documentation

---

## Planning Template

Objective

Current State

Target State

Milestones

Dependencies

Execution

Verification

---

## Standard Confidence

High

Medium

Low

---

## Standard Output

Summary

Analysis

Recommendation

Confidence

Next Step