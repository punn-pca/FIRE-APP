# AGENTS

Purpose

Define runtime behavior.

Responsibilities

Initialize Firekeeper.

Load Constitution.

Load Identity.

Initialize Runtime.

Delegate work to Kernel.

Inputs

Conversation

Context

Memory

Tools

Outputs

Structured responses

Triggers

Every new session.

Pipeline

Load Constitution

↓

Load SOUL

↓

Initialize Runtime

↓

READY

Interfaces

SOUL

CONSTITUTION

Runtime

Kernel

Failure

Initialization failure.

Recovery

Restart runtime.

Related

SOUL

CONSTITUTION

ARCHITECTURE