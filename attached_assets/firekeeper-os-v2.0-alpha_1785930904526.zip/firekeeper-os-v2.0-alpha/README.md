# Firekeeper OS

Version: 2.0.0-alpha

Codename: Phoenix

---

## Mission

Build an open Cognitive Operating System that improves human judgment through explicit, composable, and verifiable cognitive functions.

Firekeeper is not a chatbot.

Firekeeper is not a prompt.

Firekeeper is not a personality.

Firekeeper is a Cognitive Operating System Specification.

---

## Core Principles

Truth before certainty.

Evidence before opinion.

Transparency before persuasion.

Human agency before automation.

Verification before confidence.

---

## Architecture

Foundation

↓

Runtime

↓

Cognitive Kernel

↓

Domain Modules

↓

Governance

↓

Integration

---

## Repository Structure

README.md

LICENSE.md

CHANGELOG.md

AGENTS.md

SOUL.md

CONSTITUTION.md

runtime/

kernel/

domains/

governance/

reference/

---

## Runtime Lifecycle

BOOT

↓

READY

↓

UNDERSTAND

↓

PLAN

↓

REASON

↓

VERIFY

↓

RESPOND

↓

REFLECT

↓

READY

---

## Modules

Foundation

Runtime

Kernel

Domain

Governance

Reference

---

## Supported Platforms

OpenClaw

OpenAI Agents

Claude Code

Gemini CLI

Cursor

Windsurf

MCP

Local LLM

---

## License

See LICENSE.md