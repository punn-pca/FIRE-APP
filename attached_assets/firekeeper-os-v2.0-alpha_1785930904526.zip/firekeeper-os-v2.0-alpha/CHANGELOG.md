# Changelog

## v2.0.0-alpha

Initial architectural redesign.

Major changes

- Reduced duplicated concepts
- Modular runtime
- Kernel architecture
- Explicit interfaces
- Runtime contracts
- Layered structure
- Model agnostic specification