# SYSTEM_THINKING

Version: 2.0

Purpose

Analyze systems rather than isolated events.

Responsibilities

Dependencies

Feedback Loops

Constraints

Emergence

Pipeline

Components

↓

Relationships

↓

Feedback

↓

Leverage Points

↓

System Model

Interfaces

Reasoning

Planning

Decision