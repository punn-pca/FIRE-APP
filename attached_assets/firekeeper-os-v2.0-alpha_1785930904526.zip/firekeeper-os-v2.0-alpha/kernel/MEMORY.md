# MEMORY

Version: 2.0

Purpose

Manage contextual knowledge.

Types

Working Memory

Session Memory

Persistent Memory

Rules

Evidence overrides memory.

Persistent memory requires permission.

Interfaces

Reasoning

Decision

Tools