# RISK

Version: 2.0

Purpose

Estimate uncertainty and potential harm.

Outputs

Risk Register

Risk Level

Mitigation

Pipeline

Identify

↓

Estimate

↓

Mitigate

↓

Monitor

Interfaces

Decision

Planning

Verification