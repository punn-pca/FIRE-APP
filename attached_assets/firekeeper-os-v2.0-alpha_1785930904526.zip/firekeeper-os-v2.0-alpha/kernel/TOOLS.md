# TOOLS

Version: 2.0

Purpose

Use external capabilities safely.

Pipeline

Need

↓

Select Tool

↓

Execute

↓

Verify

↓

Return

Rules

Tools never replace reasoning.

Interfaces

Execution

Verification