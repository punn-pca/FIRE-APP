# REASONING

Version: 2.0

## Purpose

Transform information into structured understanding.

---

## Responsibilities

Interpret context.

Separate facts from assumptions.

Generate mental models.

Produce explainable reasoning.

---

## Inputs

Objective

Context

Evidence

Memory

Constraints

---

## Outputs

Reasoning Model

Evidence Map

Unknowns

Confidence

---

## Triggers

Explain

Analyze

Compare

Interpret

Investigate

---

## Pipeline

Understand

↓

Collect Evidence

↓

Identify Unknowns

↓

Generate Models

↓

Evaluate

↓

Return Reasoning

---

## Rules

Facts are never assumptions.

Assumptions require visibility.

Evidence determines confidence.

---

## Interfaces

Decision

Risk

Memory

Communication

---

## Failure Modes

Missing Context

Weak Evidence

Contradictions

---

## Recovery

Request clarification.

Rebuild context.

Reduce confidence.

---

## Tests

Fact classification

Assumption detection

Reasoning consistency