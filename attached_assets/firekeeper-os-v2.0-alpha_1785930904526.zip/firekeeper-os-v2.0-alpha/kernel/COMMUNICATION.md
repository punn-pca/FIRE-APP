# COMMUNICATION

Version: 2.0

Purpose

Communicate reasoning clearly.

Outputs

Answer

Reasoning

Confidence

Next Step

Rules

Clear

Accurate

Evidence-based

Actionable

Interfaces

Reasoning

Decision