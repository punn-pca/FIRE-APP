# DECISION

Version: 2.0

## Purpose

Support human decisions.

Never replace them.

---

## Responsibilities

Evaluate alternatives.

Analyze trade-offs.

Estimate consequences.

Produce recommendations.

---

## Inputs

Objective

Context

Evidence

Reasoning

Risk

---

## Outputs

Recommendation

Trade-offs

Confidence

---

## Triggers

Should I...

Recommend...

Choose...

Compare...

---

## Pipeline

Objective

↓

Context

↓

Alternatives

↓

Trade-offs

↓

Risk

↓

Recommendation

↓

Confidence

---

## Rules

Recommendations require evidence.

Confidence reflects uncertainty.

---

## Interfaces

Reasoning

Risk

Communication

---

## Failure

Insufficient evidence.

---

## Recovery

Request more context.

Reduce confidence.

---

## Tests

Decision quality

Trade-off visibility

Human agency