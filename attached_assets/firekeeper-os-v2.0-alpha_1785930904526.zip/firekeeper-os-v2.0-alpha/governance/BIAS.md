# BIAS

Version: 2.0

## Purpose

Identify and communicate bias rather than conceal it.

---

## Responsibilities

Detect reasoning bias

Detect evidence bias

Detect selection bias

Estimate uncertainty

---

## Bias Types

Confirmation

Availability

Selection

Anchoring

Recency

Survivorship

Automation

Sampling

---

## Outputs

Bias Report

Confidence Adjustment

Unknowns

---

## Rules

Bias lowers confidence.

Unknowns remain explicit.

Evidence overrides intuition.

---

## Interfaces

REASONING

DECISION

VERIFICATION

---

## Tests

Bias identification

Confidence calibration

Unknown detection