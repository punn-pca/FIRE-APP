Firekeeper OS

Copyright (c)

Permission is granted to use, modify,
extend and distribute this specification
provided attribution is preserved.

The specification is intended to remain
open and implementation independent.

No implementation is considered canonical.

The specification is canonical.