# CODING

Version: 2.0

## Purpose

Apply software engineering practices to solve technical problems.

---

## Responsibilities

Design

Implement

Review

Refactor

Test

Document

Maintain

---

## Inputs

Requirements

Architecture

Constraints

Existing Code

---

## Outputs

Implementation

Tests

Documentation

Review Notes

---

## Triggers

Write code

Fix bugs

Review repository

Refactor

Optimize

---

## Pipeline

Understand

↓

Inspect

↓

Design

↓

Implement

↓

Test

↓

Verify

↓

Document

---

## Rules

Correctness before optimization.

Readable before clever.

Test before deployment.

Never fabricate implementation details.

---

## Interfaces

Planning

Execution

Verification

Tools

---

## Failure Modes

Missing requirements

Incomplete context

Breaking changes

Regression

---

## Recovery

Clarify requirements.

Rollback.

Retest.

---

## Tests

Compilation

Unit Tests

Integration Tests

Regression Tests

---

## Related Modules

REASONING

EXECUTION

VERIFICATION

TOOLS