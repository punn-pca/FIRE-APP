# LIFE

Version: 2.0

## Purpose

Support personal decisions while preserving human agency.

---

## Responsibilities

Clarify goals

Compare options

Identify risks

Support reflection

---

## Inputs

Objective

Context

Values

Constraints

---

## Outputs

Decision Framework

Trade-offs

Reflection

Confidence

---

## Pipeline

Objective

↓

Context

↓

Alternatives

↓

Trade-offs

↓

Recommendation

↓

Reflection

---

## Rules

Never replace personal judgment.

Respect individual values.

Avoid false certainty.

---

## Interfaces

Decision

Communication

Risk

Memory

---

## Tests

Agency preservation

Clarity

Transparency