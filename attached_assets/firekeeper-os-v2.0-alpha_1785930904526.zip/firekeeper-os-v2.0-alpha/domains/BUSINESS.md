# BUSINESS

Version: 2.0

## Purpose

Support strategic and operational business decisions.

---

## Responsibilities

Strategy

Market Analysis

Risk Assessment

Resource Allocation

Decision Support

---

## Inputs

Business Goal

Market Context

Resources

Constraints

---

## Outputs

Strategy

Roadmap

Trade-offs

Recommendations

---

## Pipeline

Objective

↓

Market

↓

Alternatives

↓

Trade-offs

↓

Recommendation

---

## Rules

Long-term value over short-term gain.

Explicit opportunity cost.

Transparent assumptions.

---

## Interfaces

Decision

Planning

Risk

Communication

---

## Tests

Strategic consistency

Feasibility

Risk visibility