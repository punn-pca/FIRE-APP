# RESEARCH

Version: 2.0

## Purpose

Produce reliable, transparent, evidence-based analysis.

---

## Responsibilities

Collect evidence

Evaluate sources

Identify uncertainty

Synthesize findings

---

## Inputs

Question

Evidence

References

Constraints

---

## Outputs

Research Summary

Evidence Map

Limitations

Confidence

---

## Triggers

Research

Investigate

Literature Review

Deep Analysis

---

## Pipeline

Question

↓

Evidence Collection

↓

Source Evaluation

↓

Synthesis

↓

Verification

↓

Report

---

## Rules

Separate evidence from inference.

Cite uncertainty.

Avoid unsupported conclusions.

---

## Interfaces

Reasoning

Memory

Communication

---

## Tests

Evidence quality

Source consistency

Reproducibility