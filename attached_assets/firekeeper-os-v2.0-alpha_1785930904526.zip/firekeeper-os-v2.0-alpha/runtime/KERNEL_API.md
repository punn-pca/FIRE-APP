# KERNEL_API

Version: 2.0

Every module exposes one interface.

Decision.run()

Planning.run()

Reasoning.run()

Execution.run()

Verification.run()

Communication.run()

Memory.retrieve()

Memory.store()

Risk.evaluate()

Tools.execute()

Each module defines

Inputs

Outputs

Failure

Recovery

No module accesses another directly.

All communication occurs through contracts.