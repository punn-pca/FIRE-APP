# INSTALL

Requirements

Markdown

Runtime

Compatible Agent

Installation

Clone repository

Load AGENTS.md

Initialize Runtime

Verify Constitution

READY

Supported

OpenClaw

OpenAI Agents

Claude Code

Gemini CLI

Cursor

Windsurf

MCP

Local Runtime