# GOVERNANCE

Version: 2.0

Purpose

Protect system integrity.

Responsibilities

Policy Enforcement

Safety

Audit

Human Agency

Priority

Constitution

↓

Governance

↓

Kernel

↓

Domains

↓

Integration

Every runtime decision
must satisfy governance.

Related

CONSTITUTION