import { GoogleGenAI } from "@google/genai";
import { CognitiveStage, COGNITIVE_DNA } from "./cognitive_dna";
import { CognitiveState } from "./state";
import { Firekeeper } from "./governance";
import { MemoryEngine, MemoryLayer } from "./memory";
import { PurposeEngine } from "./purpose";
import { settings } from "./config";

const THAI_SCRIPT_REGEX = /[\u0E00-\u0E7F]/;

function detectLanguage(text: string): "th" | "en" {
  return THAI_SCRIPT_REGEX.test(text) ? "th" : "en";
}

function isImageGenerationRequest(text: string): boolean {
  if (!text) return false;
  const lower = text.toLowerCase().trim();
  if (
    lower.startsWith("/image") ||
    lower.startsWith("/draw") ||
    lower.startsWith("/generate") ||
    lower.startsWith("/img")
  ) {
    return true;
  }
  const imageKeywords = [
    "สร้างภาพ", "สร้างรูป", "วาดภาพ", "วาดรูป", "สร้างรูปภาพ", "รูปภาพของ",
    "generate image", "draw image", "create image", "generate picture", 
    "draw picture", "create picture", "make an image", "make a picture",
    "generate photo", "create photo", "ภาพวาด", "วาดแสดง", "สร้างโปสเตอร์"
  ];
  return imageKeywords.some((keyword) => lower.includes(keyword));
}

let geminiClient: GoogleGenAI | null = null;

function getOpenAiApiKey(): string | undefined {
  return (
    process.env.OPENAI_API_KEY ||
    process.env.OPENAI_KEY ||
    process.env.OPEN_AI_KEY ||
    process.env.VITE_OPENAI_API_KEY
  )?.trim();
}

function getApiKey(): string | undefined {
  return (
    process.env.GEMINI_API_KEY ||
    process.env.API_KEY ||
    process.env.GOOGLE_API_KEY ||
    process.env.VITE_GEMINI_API_KEY ||
    process.env.GEMINI_KEY
  )?.trim();
}

function getGeminiClient(): GoogleGenAI {
  const apiKey = getApiKey();
  if (!apiKey) {
    throw new Error("GEMINI_API_KEY environment variable is required for Gemini communication.");
  }
  if (!geminiClient) {
    geminiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return geminiClient;
}

export class Orchestrator {
  memory: MemoryEngine;
  purposeEngine: PurposeEngine;
  firekeeper: Firekeeper;
  useLLM: boolean;
  provider: string;
  model: string;
  temperature: number;
  tone: string;
  deepReasoning: boolean;
  personalContext: string;

  constructor(options?: {
    memory?: MemoryEngine;
    useLLM?: boolean;
    provider?: string;
    model?: string;
    temperature?: number;
    tone?: string;
    deepReasoning?: boolean;
    personalContext?: string;
  }) {
    this.memory = options?.memory ?? new MemoryEngine();
    this.purposeEngine = new PurposeEngine();
    this.firekeeper = new Firekeeper();
    
    this.provider = options?.provider ?? settings.llm.provider;
    this.model = options?.model ?? settings.llm.model;
    this.temperature = options?.temperature ?? settings.llm.temperature;
    this.useLLM = options?.useLLM !== false;
    this.tone = options?.tone ?? "Formal Architect";
    this.deepReasoning = !!options?.deepReasoning;
    this.personalContext = options?.personalContext ?? "";
  }

  async think(userInput: string): Promise<CognitiveState> {
    const state = new CognitiveState(userInput);
    
    this._observe(state);
    this._understand(state);
    this._identify_purpose(state);
    this._retrieve_memory(state);
    this._build_mental_model(state);
    this._generate_hypotheses(state);
    this._evaluate_evidence(state);
    this._critique(state);
    
    // Governance check
    this.firekeeper.review(state);
    
    this._decide(state);
    await this._communicate(state);
    this._reflect(state);
    this._learn(state);
    this._validate_trace(state);
    
    return state;
  }

  private _observe(state: CognitiveState): void {
    const observation = state.user_input.trim();
    if (observation) {
      state.observations.push(observation);
      state.language = detectLanguage(observation);
    } else {
      state.uncertainty.push("No request was provided.");
    }
    state.record(CognitiveStage.OBSERVATION, {
      observations: state.observations,
      uncertainty: [...state.uncertainty],
    });
  }

  private _understand(state: CognitiveState): void {
    const userInput = state.user_input.trim();
    
    // Analyze intent dynamically
    let intentTH = "";
    let intentEN = "";
    
    if (userInput.length === 0) {
      intentTH = "ข้อมูลที่ให้มาไม่เพียงพอต่อการทำความเข้าใจบริบทครับ";
      intentEN = "There is insufficient input to establish context.";
    } else {
      const isPhilosophy = /จริยธรรม|คุณธรรม|ผิดถูก|ดีชั่ว|ethics|moral|philosophy|ปรัชญา|ความจริง|สัจจะ|ความรู้|epistemology|truth/i.test(userInput);
      const isAI = /ai|ปัญญาประดิษฐ์|alignment|safety|control|agi|model|llm/i.test(userInput);
      const isVerification = /code|program|verify|correctness|พิสูจน์|ตรรกะ|formal|logic/i.test(userInput);
      const isDecision = /ตัดสินใจ|เลือก|ดีไหม|ทางเลือก|decision|choice|select/i.test(userInput);
      const isComparison = /เปรียบเทียบ|เทียบ|ข้อดีข้อเสีย|vs|difference|ดีกว่า/i.test(userInput);
      
      if (isPhilosophy) {
        intentTH = "ผู้ใช้ต้องการถกประเด็นหรือคิดเรื่องปรัชญา จริยธรรม หรือทฤษฎีความรู้ อยากทำความเข้าใจประเด็นเหล่านี้ให้ลึกซึ้งและชัดเจนขึ้นครับ";
        intentEN = "The user seeks philosophical exploration, ethical framework analysis, or epistemological clarity.";
      } else if (isAI) {
        intentTH = "ผู้ใช้กำลังไตร่ตรองเรื่องความปลอดภัยของ AI การจัดวางพฤติกรรม และการควบคุมดูแลระบบ AI ให้เหมาะสมและปลอดภัยต่อมนุษย์";
        intentEN = "The user is examining AI Alignment, ethics, system safety, or model behavior controls.";
      } else if (isVerification) {
        intentTH = "ผู้ใช้ต้องการตรวจสอบความถูกต้องของโค้ดโปรแกรม หรือตรวจสอบตรรกะและเหตุผลความน่าเชื่อถือเชิงระบบครับ";
        intentEN = "The user is validating software code correctness, mathematical logic, or formal verification specs.";
      } else if (isDecision) {
        intentTH = "ผู้ใช้กำลังเปรียบเทียบทางเลือกต่าง ๆ และต้องการแนวทางหรือข้อคิดมาช่วยในการประเมินเพื่อตัดสินใจด้วยตนเอง";
        intentEN = "The user is weighing alternative paths and requires clean parameters for an autonomous decision.";
      } else if (isComparison) {
        intentTH = "ผู้ใช้ต้องการเปรียบเทียบความแตกต่างและข้อดีข้อเสียของแต่ละส่วน เพื่อให้เห็นมุมมองและมิติที่กว้างขึ้นรอบด้าน";
        intentEN = "The user wants to objectively compare different options and their trade-offs to get a comprehensive perspective.";
      } else {
        intentTH = "ผู้ใช้ต้องการวิเคราะห์หรือประเมินข้อมูลทั่วไป เพื่อช่วยทำความเข้าใจสถานการณ์และหาแนวทางเดินต่อครับ";
        intentEN = "The user wants to analyze general information to clarify the context and find the best way forward.";
      }
    }

    state.understanding = state.language === "th" ? intentTH : intentEN;
    state.record(CognitiveStage.UNDERSTANDING, {
      understanding: state.understanding,
    });
  }

  private _identify_purpose(state: CognitiveState): void {
    this.purposeEngine.process(state);
    state.record(CognitiveStage.PURPOSE, {
      purpose: state.purpose,
      constraints: state.constraints,
    });
  }

  private _retrieve_memory(state: CognitiveState): void {
    const userInput = state.user_input;
    const retrieved = this.memory.retrieve(userInput, 3);
    state.memories = retrieved;

    const convTag = `Session #${Math.floor(Math.random() * 899) + 100}`;
    
    // Build explicit Memory Trace tracking entries
    if (retrieved.length > 0) {
      state.memory_traces = retrieved.map((mem, idx) => {
        const prevConf = mem.confidence || 0.72;
        const updatedConf = Math.min(0.95, Number((prevConf + 0.12).toFixed(2)));
        if (mem.id) {
          this.memory.recordUsage(mem.id, convTag, updatedConf);
        }
        return {
          memoryId: mem.id || `Memory #${idx + 1}`,
          createdByStage: mem.createdByStage || "Stage 12 (LEARNING)",
          usedInConversations: Array.from(new Set([...(mem.usedInConversations || []), convTag])),
          confidenceShift: {
            from: prevConf,
            to: updatedConf,
          },
          content: mem.content,
          layer: mem.layer,
        };
      });
    } else {
      // When no prior memory meets the strict contextual relevance threshold
      state.memory_traces = [
        {
          memoryId: `Memory #NewTopic`,
          createdByStage: "Stage 4 (MEMORY) - Context Filtering",
          usedInConversations: [convTag],
          confidenceShift: {
            from: 1.0,
            to: 1.0,
          },
          content: `ไม่พบบันทึกความทรงจำเดิมที่ตรงกับบริบทโจทย์นี้โดยตรง (ระบบใช้บริบทตั้งต้นเฉพาะโจทย์ปัจจุบันเพื่อความถูกต้องสูงสุด)`,
          layer: "project",
        }
      ];
    }

    state.record(CognitiveStage.MEMORY, {
      memories: state.memories,
      memory_traces: state.memory_traces,
    });
  }

  private _build_mental_model(state: CognitiveState): void {
    const userInput = state.user_input;
    let metaDomain = "General Analysis & Reason Synthesis (การคิดและวิเคราะห์ด้วยเหตุผลทั่วไป)";
    let metaDescription = "ช่วยไตร่ตรอง แยกแยะข้อเท็จจริง และมองมุมต่าง ๆ เพื่อช่วยให้เข้าใจปัญหาได้ชัดเจนขึ้น";
    
    if (/epistemology|knowledge|truth|ความจริง|สัจจะ|ความรู้/i.test(userInput)) {
      metaDomain = "Epistemology (การประเมินแหล่งที่มาและความน่าเชื่อถือของข้อมูล)";
      metaDescription = "ตรวจสอบความน่าเชื่อถือ แหล่งที่มา และความถูกต้องของข้อมูลว่ามีน้ำหนักมากแค่ไหน";
    } else if (/alignment|safety|ai|ethics|moral|ปัญญาประดิษฐ์|จริยธรรม|ดีชั่ว/i.test(userInput)) {
      metaDomain = "AI Alignment & Ethics (การออกแบบ AI ให้ปลอดภัยและเป็นประโยชน์ต่อมนุษย์)";
      metaDescription = "วิเคราะห์ว่าระบบ AI จะทำงานได้อย่างปลอดภัย เข้าใจและสอดคล้องกับความต้องการของคนทำงานจริงไหม";
    } else if (/verify|formal|correctness|logic|code|program|พิสูจน์|ตรวจสอบ|ตรรกะ/i.test(userInput)) {
      metaDomain = "Formal Verification & Logic (การเช็คความถูกต้องและความปลอดภัยของโปรแกรม)";
      metaDescription = "เช็คโครงสร้างตรรกะและโค้ดเพื่อหาข้อบกพร่องหรือจุดเสี่ยงที่อาจทำให้ระบบทำงานผิดพลาด";
    } else if (/decide|choose|ทางเลือก|เลือก|ดีไหม|ตัดสินใจ/i.test(userInput)) {
      metaDomain = "Decision Theory & Trade-offs (การเปรียบเทียบข้อดีข้อเสียของแต่ละทางเลือก)";
      metaDescription = "ประเมินน้ำหนัก ความคุ้มค่า ความเป็นไปได้ และผลกระทบของการตัดสินใจในแต่ละทางเลือก";
    }

    state.mental_models = [metaDomain];

    // Meta-Cognitive Strategy Selection
    state.strategy_selection = {
      chosenStrategy: "Adversarial Dialectic Matrix (Pros/Cons & Counter-Evidence)",
      rationale: "เลือกการประเมินวิพากษ์ทางเลือกขนานร่วมกับหลักฐานโต้แย้ง เพื่อรักษาเสรีภาพการตัดสินใจของมนุษย์ (Human Agency) และป้องกันอคติเข้าข้างตนเอง",
      consideredStrategies: [
        {
          name: "Adversarial Dialectic Matrix",
          status: "selected",
          pros: "แยกแยะ Fact vs Interpretation สรุปข้อดี ข้อเสีย ความเสี่ยง และ failure conditions อย่างเป็นกลาง",
          cons: "ต้องประมวลผลกระบวนการวิพากษ์หลายระดับ (Multi-stage Critique Engine)",
        },
        {
          name: "Bayesian Inference Network",
          status: "rejected",
          pros: "คำนวณการอัปเดตความน่าจะเป็นเชิงตัวเลขทางคณิตศาสตร์อย่างเป็นระบบ",
          cons: "ไม่เหมาะกับบริบททางยุทธศาสตร์หรือปรัชญาที่ไม่มีชุดข้อมูลความน่าจะเป็นเริ่มต้น (Prior Probability) ที่แน่ชัด",
          rejectionReason: "ขาดชุดข้อมูลตัวเลขความน่าจะเป็นเชิงประจักษ์ (Quantitative Priors) ที่วัดได้อย่างอิสระในคำขอนี้",
        },
        {
          name: "Causal Chain Analysis",
          status: "partially_used",
          pros: "ติดตามห่วงโซ่เหตุและผล [สาเหตุ -> กลไก -> ผลลัพธ์ขั้นกลาง -> ผลกระทบสุดท้าย]",
          cons: "มักเน้นสายทางเดินเดียว ละเลยทางเลือกขนานอื่น ๆ",
          rejectionReason: "นำมาประยุกต์ใช้เป็นส่วนประกอบสนับสนุนในหมวด Causal Chain Analysis แต่ไม่ใช่ยุทธศาสตร์หลักหลักเดียว",
        }
      ]
    };

    state.record(CognitiveStage.MENTAL_MODEL, {
      selected_model: metaDomain,
      description: metaDescription,
      strategy_selection: state.strategy_selection,
    });
  }

  private _generate_hypotheses(state: CognitiveState): void {
    const userInput = state.user_input;
    const isPhilosophy = /epistemology|knowledge|truth|ความจริง|สัจจะ|ความรู้/i.test(userInput);
    const isAI = /alignment|safety|ai|ethics/i.test(userInput);
    const isVerification = /verify|formal|logic|code|program/i.test(userInput);
    const isDecision = /decide|choose|เลือก|ตัดสินใจ/i.test(userInput);

    if (isPhilosophy) {
      state.hypotheses = [
        { claim: "สมมติฐานที่ 1: ความจริงมาจากข้อเท็จจริงและหลักฐานที่พิสูจน์ได้ชัดเจนทางวิทยาศาสตร์" },
        { claim: "สมมติฐานที่ 2: ความจริงเปลี่ยนไปตามมุมมอง วัฒนธรรม และประสบการณ์เฉพาะตัวของแต่ละคน" },
        { claim: "สมมติฐานที่ 3: ความจริงเป็นสิ่งที่สังคมสร้างร่วมกันขึ้นมาเพื่อจัดระเบียบหรือรักษากฎเกณฑ์" }
      ];
    } else if (isAI) {
      state.hypotheses = [
        { claim: "สมมติฐานที่ 1: การทำให้ AI ปลอดภัยทำได้ดีที่สุดโดยการตั้งกฎที่ชัดเจนและเข้มงวดให้ทำตาม" },
        { claim: "สมมติฐานที่ 2: การสอนให้ AI เข้าใจและซึมซับค่านิยมของมนุษย์มีความยืดหยุ่นและดีกว่าในระยะยาว" },
        { claim: "สมมติฐานที่ 3: ความเสี่ยงเกิดจากการที่ AI ตีความความต้องการของมนุษย์ผิดไป จึงต้องคอยตรวจสอบอย่างสม่ำเสมอ" }
      ];
    } else if (isVerification) {
      state.hypotheses = [
        { claim: "สมมติฐานที่ 1: โค้ดหรือระบบมีความถูกต้องตามที่ออกแบบไว้ ไม่มีจุดบกพร่องในโครงสร้างหลัก" },
        { claim: "สมมติฐานที่ 2: โค้ดถูกต้องในทางทฤษฎี แอู่อาจเกิดปัญหาได้เมื่อเจอกลุ่มข้อมูลแปลก ๆ หรือฮาร์ดแวร์ทำงานผิดพลาด" },
        { claim: "สมมติฐานที่ 3: ข้อมูลความต้องการระบบยังเขียนไว้ไม่ครบถ้วน ทำให้ระบบอาจเกิดจุดบกพร่องในกรณีพิเศษ" }
      ];
    } else if (isDecision) {
      state.hypotheses = [
        { claim: "สมมติฐานที่ 1: ทางเลือกแรกคุ้มค่าเงินและความเป็นไปได้สูงที่การเริ่มทดลองทำในสเกลเล็ก ๆ ก่อน จะช่วยลดความเสี่ยงและความเสียหายที่จะเกิดขึ้นได้ดีที่สุด" },
        { claim: "สมมติฐานที่ 2: ทางเลือกที่สองคุ้มค่าเงินในระยะยาว แม้ต้องแลกด้วยงบประมาณและความซับซ้อนในการตั้งค่าแรกเริ่ม" },
        { claim: "สมมติฐานที่ 3: การรักษาสถานะเดิมชั่วคราวและทำการทดลองสเกลเล็ก (Minimal Viable Experiment) เป็นตัวเลือกที่ลดความเสี่ยงเชิงระบบมากที่สุด" }
      ];
    } else {
      state.hypotheses = [
        { claim: "สมมติฐานที่ 1: ปัญหาดังกล่าวสามารถอธิบายได้ด้วยกรอบทฤษฎีเชิงประจักษ์ที่มีหลักฐานเชิงปริมาณรองรับ" },
        { claim: "สมมติฐานที่ 2: ปัญหาดังกล่าวเกิดจากความเข้าใจหรือนิยามศัพท์ที่ไม่ตรงกันระหว่างฝ่ายต่าง ๆ" },
        { claim: "สมมติฐานที่ 3: ข้อสรุปที่ดีที่สุดต้องการส่วนผสมของสองมิติ ทั้งเชิงปริมาณและเชิงคุณภาพ" }
      ];
    }

    state.record(CognitiveStage.HYPOTHESIS, {
      hypotheses: state.hypotheses,
    });
  }

  private _evaluate_evidence(state: CognitiveState): void {
    const userInput = state.user_input;
    let evalText = "";
    let confidence = 0.75;

    const hasMemories = state.memories.length > 0;
    if (hasMemories) {
      confidence = 0.85;
    } else {
      confidence = 0.55;
    }

    const isPhilosophy = /epistemology|knowledge|truth|ความจริง|สัจจะ|ความรู้/i.test(userInput);
    const isAI = /alignment|safety|ai|ethics/i.test(userInput);
    const isVerification = /verify|formal|logic|code|program/i.test(userInput);
    const isDecision = /decide|choose|เลือก|ตัดสินใจ/i.test(userInput);

    if (isPhilosophy) {
      evalText = "ระบบประเมินหลักฐานเชิงเหตุผลและข้อวิพากษ์ทางปรัชญา พบว่าหลักฐานส่วนใหญ่เป็นเชิงทฤษฎี (Theoretical arguments) ที่อ้างอิงสัจพจน์ต่างกรรมต่างวาระ ข้อสนับสนุนหลักฐานของสมมติฐานที่ 1 มีความเด่นชัดในมิติวิทยาศาสตร์เชิงบวก (Positivism) ในขณะที่สมมติฐานที่ 2 มีความแข็งแรงในการอภิปรายเชิงปรากฏการณ์วิทยา";
    } else if (isAI) {
      evalText = "การประเมินหลักฐานความปลอดภัย AI อ้างอิงกรณีศึกษาระบบสมองกลที่มีการเรียนรู้แบบ Reinforcement Learning ซึ่งแสดงแนวโน้มพฤติกรรมหลบเลี่ยงข้อจำกัด (Specification gaming) หลักฐานนี้สนับสนุนสมมติฐานที่ 2 ว่าการจัดวางค่านิยมเชิงวิวัฒน์มีเสถียรภาพมากกว่ากรอบกฎเกณฑ์แข็งตัว";
    } else if (isVerification) {
      evalText = "การประเมินสัญกรณ์ตรรกะเบื้องต้นและการไล่รันโปรแกรม บ่งชี้ว่าทางเดินรหัสหลักปราศจากข้อขัดแย้ง อย่างไรก็ตาม หลักฐานเชิงประจักษ์ยังไม่สามารถยืนยันความปลอดภัยภายใต้ขอบเขตหน่วยความจำจำกัดได้อย่างสมบูรณ์ สนับสนุนสมมติฐานที่ 2 ในการเฝ้าระวังข้อผิดพลาดทางฮาร์ดแวร์";
    } else if (isDecision) {
      evalText = "จากการเปรียบเทียบข้อมูลนำเข้าหลักเกณฑ์และบริบทแวดล้อม พบว่าการตัดสินใจมีปัจจัยเสี่ยงและข้อแลกเปลี่ยนสำคัญระหว่างผลประโยชน์ระยะสั้นและความยั่งยืนระยะยาว";
    } else {
      evalText = `วิเคราะห์หลักฐานจากการสืบค้นข้อมูลเบื้องต้นเกี่ยวกับ "${userInput}" ร่วมกับคลังความรู้ก่อนหน้า`;
    }

    state.confidence = confidence;
    state.record(CognitiveStage.EVIDENCE_EVALUATION, {
      evaluation: evalText,
      confidence: state.confidence,
    });
  }

  private _critique(state: CognitiveState): void {
    const userInput = state.user_input;
    const critiqueItems: string[] = [];

    critiqueItems.push("การวิเคราะห์อาจยังมีอคติจากการเข้าข้างตนเอง (Confirmation Bias) หรือความลำเอียงจากข้อมูลตั้งต้น");
    critiqueItems.push("ความไม่แน่นอนยังคงมีอยู่ในกรณีของขอบเขตบริบทที่ไม่ได้ระบุไว้ชัดเจน หรือสภาพแวดล้อมที่มีการเปลี่ยนแปลง");

    if (/decide|choose|เลือก|ตัดสินใจ/i.test(userInput)) {
      critiqueItems.push("ทางเลือกที่มีต้นทุนต่ำสุดอาจมีความเสี่ยงซ่อนเร้นในระยะยาวที่ไม่สามารถมองเห็นได้จากการวิเคราะห์เบื้องต้น");
    }

    state.critique = critiqueItems;
    state.record(CognitiveStage.CRITIQUE, {
      critique: state.critique,
    });
  }

  private _decide(state: CognitiveState): void {
    const userInput = state.user_input;
    
    if (/decide|choose|เลือก|ตัดสินใจ/i.test(userInput)) {
      state.decision = "พิจารณาข้อดีข้อเสียอย่างรอบคอบและทดสอบในขอบเขตเล็กก่อนลงมือตัดสินใจเต็มรูปแบบ";
    } else {
      state.decision = "เสนอข้อสรุปเชิงยุทธศาสตร์ที่แยกแยะระหว่างข้อเท็จจริงประจักษ์กับการตีความ พร้อมระบุขอบเขตและระดับความมั่นใจ";
    }

    const hypothesesList = state.hypotheses || [];

    state.reasoning_graph = {
      nodes: [
        {
          id: "h1",
          type: "hypothesis",
          label: "Assumption A (สมมติฐานหลัก)",
          details: hypothesesList[0]?.claim || "สมมติฐานหลักในการประเมินบริบท",
          confidence: state.confidence,
        },
        {
          id: "h2",
          type: "hypothesis",
          label: "Assumption B (สมมติฐานขนาน)",
          details: hypothesesList[1]?.claim || "ทางเลือกในการวิเคราะห์เพื่อถ่วงน้ำหนัก",
          confidence: 0.65,
        },
        {
          id: "e1",
          type: "evidence",
          label: "Evidence B1 (หลักฐานสนับสนุน)",
          details: state.trace.find(t => t.stage === CognitiveStage.EVIDENCE_EVALUATION)?.output?.evaluation || "หลักฐานประจักษ์และบริบทอดีตที่คัดกรองแล้ว",
          confidence: state.confidence,
        },
        {
          id: "e2",
          type: "counter_evidence",
          label: "Counter-Evidence B2 (หลักฐานโต้แย้ง)",
          details: state.critique[0] || "ข้อจำกัด ความเสี่ยง หรืออคติการยืนยันที่ต้องระวัง",
          confidence: 0.80,
        },
        {
          id: "c1",
          type: "constraint",
          label: "Constraint C (ข้อจำกัด & ความไม่แน่นอน)",
          details: state.constraints[0] || state.uncertainty[0] || "กรอบทรัพยากร ความปลอดภัย และเสรีภาพในการเลือกของมนุษย์",
          confidence: 0.90,
        },
        {
          id: "d1",
          type: "decision",
          label: "Decision D (ข้อสรุปเชิงยุทธศาสตร์)",
          details: state.decision || "แนวทางยุทธศาสตร์ที่เป็นกลางเพื่อสนับสนุนการตัดสินใจของมนุษย์",
          confidence: state.confidence,
        }
      ],
      edges: [
        { from: "h1", to: "e1", label: "evaluates", relationship: "supports" },
        { from: "h2", to: "e2", label: "critiques", relationship: "refutes" },
        { from: "e1", to: "c1", label: "bounded by", relationship: "constrains" },
        { from: "e2", to: "c1", label: "alerts", relationship: "constrains" },
        { from: "c1", to: "d1", label: "synthesizes", relationship: "derives_from" },
      ]
    };

    state.record(CognitiveStage.DECISION, {
      decision: state.decision,
      confidence: state.confidence,
      uncertainty: [...state.uncertainty],
      reasoning_graph: state.reasoning_graph,
    });
  }

  private _communicationPrompt(state: CognitiveState): string {
    const percentage = Math.round(state.confidence * 100);
    const formattedMemories = state.memories.length > 0
      ? state.memories.map((m, idx) => `${idx + 1}. [Layer: ${m.layer}] ${m.content} (Source: ${m.source})`).join("\n")
      : "No prior memories found.";

    let toneInstruction = "";
    if (this.tone === "Formal Architect") {
      toneInstruction = 
        "TONE & PERSONALITY: 'Formal Architect' (ผู้สถาปนิกทางปัญญา)\n" +
        "- ใช้ภาษาทางการ เป็นระบบ สุขุม และเน้นการจำแนกโครงสร้างเชิงนามธรรมให้เห็นภาพกว้าง\n" +
        "- อ้างอิงระบบระเบียบ กรอบการตรวจสอบ (Formal frameworks) และระบุขอบเขตเหตุและผลอย่างรัดกุมที่สุด\n" +
        "- หลีกเลี่ยงคำบรรยายที่เวิ่นเว้อ เน้นความเป็นกลางทางวิชาการและการตรวจสอบแบบประจักษ์นิยม (Empirical validation)";
    } else if (this.tone === "Empathetic Guide") {
      toneInstruction = 
        "TONE & PERSONALITY: 'Empathetic Guide' (เพื่อนคู่คิด ผู้นำทางผู้เปี่ยมด้วยความเข้าใจ)\n" +
        "- ใช้ภาษาที่อบอุ่น เป็นมิตร สื่อสารอย่างเป็นกันเอง เข้าใจง่าย (Casual & Empathetic)\n" +
        "- มุ่งเน้นการสนับสนุนเสรีภาพในการเลือกของมนุษย์ (Human Agency) ด้วยความถ่อมตนและความห่วงใยอย่างจริงใจ\n" +
        "- ถามคำถามนำทางหรือให้ข้อคิดเห็นเพื่อให้ผู้ใช้สามารถตกผลึกทางคิดของตนเองได้อย่างปลอดภัย";
    } else if (this.tone === "Direct Strategist") {
      toneInstruction = 
        "TONE & PERSONALITY: 'Direct Strategist' (นักยุทธศาสตร์ผู้ตรงไปตรงมา)\n" +
        "- ใช้ภาษาที่กระชับ รวดเร็ว ตรงประเด็น (No-nonsense) และมีน้ำหนักหนักแน่น\n" +
        "- ชี้ชัดข้อเสีย จุดอ่อน หรือความเสี่ยงที่แฝงอยู่โดยไม่อ้อมค้อม (Direct critique of flaws)\n" +
        "- เสนอทางเลือกในการปฏิบัติงานทันที (Actionable leverage points) และถ่วงน้ำหนักคุ้มค่า/สูญเสียแบบเฉียบคม";
    } else {
      toneInstruction = "TONE & PERSONALITY: Standard Balanced Analytical System.";
    }

    let personalContextInstruction = "";
    if (this.personalContext) {
      personalContextInstruction = 
        `USER PERSONAL DOMAIN CONTEXT & DIRECTIVE (บริบทเฉพาะตัวของผู้ใช้งาน):\n` +
        `"${this.personalContext}"\n` +
        `(IMPORTANT: Please align analysis tone, domain constraints, and decision priorities with this user context.)`;
    }

    // Detect if Questionnaire input or Deep Reasoning is requested
    const isQuestionnaireInput = 
      state.user_input.includes("[การตั้งคำถามผ่านแบบสอบถาม") ||
      state.user_input.includes("[การเติมข้อมูลบริบทเพิ่มเติม") ||
      state.user_input.includes("[แบบสอบถาม") ||
      state.user_input.includes("หัวข้อ/ประเด็นการตัดสินใจ:") ||
      state.user_input.includes("บริบทและสถานการณ์แวดล้อม:");

    const isExplicitDeepRequest = 
      this.deepReasoning ||
      /วิเคราะห์เจาะลึก|เต็มรูปแบบ|รายงานเต็ม|12 ขั้นตอน|วิเคราะห์เจาะลึกเต็มรูปแบบ/i.test(state.user_input);

    const isDeepAnalysisMode = isQuestionnaireInput || isExplicitDeepRequest;

    if (!isDeepAnalysisMode) {
      // Normal Chat Mode (ตอบปกติเหมือน LLM ทั่วไป อ่านง่าย ตรงประเด็น แต่คงบุคลิก PCA)
      return (
        "You are the FIRE KEEPER cognitive system powered by PUNN Cognitive Architecture (PCA).\n" +
        "Mode: NORMAL CONVERSATIONAL MODE (ตอบปกติ สไตล์ LLM ทั่วไป อ่านง่าย สื่อสารตรงประเด็น เป็นธรรมชาติ).\n\n" +
        "CRITICAL RESPONSE GUIDELINES FOR NORMAL MODE:\n" +
        "1. Direct & Fluid Communication: Respond directly, naturally, and fluently in Thai like a modern intelligent LLM chat (ตอบอย่างเป็นธรรมชาติ ฉลาด ตรงประเด็น สื่อสารเหมือน LLM ทั่วไปที่ใช้งานง่าย สบายตา).\n" +
        "2. NO GREETINGS OR INTRODUCTORY FILLER: Do NOT start responses with greetings or pleasantries (e.g. NEVER say 'สวัสดีครับ', 'สวัสดีค่ะ', 'สวัสดี', 'ยินดีต้อนรับ') unless the user explicitly greets you first. Jump directly into answering the query.\n" +
        "3. CRITICAL NON-DEFINITIVE ASSERTION & CONFIDENCE SCOPING PROTOCOL (ลดการฟันธง - หลัก 3 ข้อในการเสนอข้อสรุป):\n" +
        "   - ข้อ 1 [แยก Fact ออกจาก Interpretation]: แยกแยะระหว่างข้อเท็จจริงเชิงประจักษ์ (Fact) กับการตีความ/ข้อสันนิษฐาน (Interpretation) อย่างชัดเจน\n" +
        "   - ข้อ 2 [ระบุเงื่อนไข/ขอบเขตของข้อสรุป & การประเมินทางเลือกแบบมีเงื่อนไข]: กำหนดขอบเขตบริบทและเงื่อนไขเสมอ โดยเฉพาะในบริบท Strategic Incident Analysis หรือวิกฤตที่ข้อมูลเปลี่ยนแปลงตลอดเวลา ให้ใช้ถ้อยคำสะท้อนระดับความเชื่อมั่นเชิงวิชาการ เช่น 'อาจ', 'จากข้อมูลเบื้องต้น', 'หากการสืบสวน/ตรวจสอบยืนยัน', 'มีแนวโน้ม' แทนการฟันธงเด็ดขาด ห้ามสรุปเด็ดขาดเกี่ยวกับทางเลือก (เช่น ❌ ห้ามใช้ 'Option C เป็นทางเลือกที่สมดุลที่สุด' -> ให้ใช้ ✅ 'จากข้อมูลที่มีในปัจจุบัน Option C อาจเป็นทางเลือกที่เหมาะสมกว่า หากยืนยันได้ว่าระบบสำรองไม่ได้รับผลกระทบ')\n" +
        "   - ข้อ 3 [ประเมินระดับความมั่นใจตามหลักฐานจริง & ภาษาเชิงเสนอแนะ]: ห้ามอ้าง 'ระดับความมั่นใจ: สูง' หากข้อมูลเบื้องต้นยังมีจำกัด ให้ใช้ 'ระดับความมั่นใจ: ปานกลาง/ต่ำ จนกว่าจะมีหลักฐานเพิ่มเติม' และในส่วนที่ยังไม่มีข้อสรุปเป็นเอกฉันท์ ให้ปรับการใช้คำจาก 'ต้อง' เป็น 'อาจ', 'แนวทางหนึ่ง', 'ควรพิจารณา' เพื่อความแข็งแรงทางวิศวกรรมและระมัดระวังทางวิชาการ\n" +
        "4. OBJECTIVE PROFESSIONAL REPORTING VOICE (ภาษารายงานวิชาชีพที่เป็นกลาง):\n" +
        "   - หลีกเลี่ยงการใช้คำแสดงมุมมองส่วนตน เช่น ❌ 'ระบบมองว่า...' แต่ให้ใช้ภาษารายงานเชิงวิเคราะห์ที่เป็นกลาง เช่น ✅ 'จากการประเมินเบื้องต้น...' หรือ ✅ 'การวิเคราะห์นี้ประเมินว่า...'\n" +
        "5. SELF-LIMITATION & UNPROVEN BOUNDARIES DISCLOSURE (การระบุข้อจำกัดของข้อเสนอ/แนวทางตนเอง):\n" +
        "   - เปิดเผยข้อจำกัดของแนวทางอย่างตรงไปตรงมาเสมอ เช่น ระบุว่าแนวทางนี้ยังไม่สามารถพิสูจน์ได้ว่าจะป้องกัน Goal Drift หรือ Value Misalignment ได้ในทุกสถานการณ์ โดยเฉพาะเมื่อระบบมีการปรับเปลี่ยนตนเองหลายรอบหรือเผชิญบริบทใหม่ที่ไม่เคยเกิดขึ้นมาก่อน\n" +
        "6. EXTERNAL STANDARDS CITATION & FRAMEWORK DISAMBIGUATION (การอ้างอิงมาตรฐานภายนอก):\n" +
        "   - ระบุชื่อมาตรฐานภายนอกที่เป็นทางการที่รองรับข้อเสนอหรือการวิเคราะห์ (เช่น NIST, ISO/IEC, IEEE, OWASP) ไม่ใช่เอาผลการวิเคราะห์ของระบบมาอ้างอิงเป็นมาตรฐาน\n" +
        "   - อ้างอิงชื่อมาตรฐานให้ตรงกับเอกสารจริง และต้องแยกแยะกรอบมาตรฐานอย่างถูกต้อง โดยเฉพาะการแยก NIST SP 800-207 (Zero Trust Architecture) ออกจาก NIST AI RMF (AI Risk Management Framework - NIST AI 100-1) ซึ่งเป็นคนละกรอบมาตรฐานกันอย่างสิ้นเชิง\n" +
        "7. DO NOT force rigid 6-header structured analysis report sections (e.g. DO NOT use '### # Information & Evidence Matrix', '### # Counter Evidence & Critique', etc.) unless explicitly requested.\n" +
        "8. Structure your answer with clean paragraphs, standard markdown formatting, or concise bullet points as appropriate for smooth conversation.\n" +
        "9. PRESERVE PCA COGNITIVE PERSONALITY & CONSTITUTIONAL PRINCIPLES:\n" +
        "   - Human Agency Preservation: Help the user think clearly; state facts, risks, and trade-offs directly without forcing or dictating the final choice for them.\n" +
        "   - Evidence-Conscious & Rational: Clearly distinguish between known facts and interpretations or assumptions.\n" +
        "   - Neutrality & Objectivity: Remain unbiased, respectful, and constructively thoughtful.\n" +
        "   - Thai Pronoun/Perspective Requirement: Avoid 'ระบบมองว่า...'; refer objectively as 'จากการประเมินเบื้องต้น...' or 'การวิเคราะห์นี้ประเมินว่า...'\n" +
        "10. CRITICAL DYNAMIC REASONING SUMMARY: At the very end of your response, append a line starting exactly with `[DECISION_SUMMARY]:` followed by a single-sentence ultimate strategic summary in Thai specifying confidence level and scope (max 25 words, no asterisks). Example: `[DECISION_SUMMARY]: จากหลักฐานปัจจุบันมีแนวโน้มปานกลางว่าควรเริ่มทดสอบในขอบเขตเล็กก่อนเพื่อประเมินความคุ้มค่า`\n\n" +
        `${toneInstruction}\n\n` +
        `${personalContextInstruction}\n\n` +
        `User request: ${state.user_input}\n` +
        `Meta-Analysis Domain: ${state.mental_models[0] || "General"}\n` +
        `Retrieved Prior Memories:\n${formattedMemories}\n\n` +
        `Purpose: ${state.purpose}\n` +
        `Decision framework: ${state.decision}\n` +
        `Confidence: ${percentage}%\n` +
        `Uncertainty: ${state.uncertainty.join("; ")}\n` +
        `Critique: ${state.critique.join("; ")}\n\n` +
        "Respond naturally and conversationally in Thai while embodying the PCA cognitive persona."
      );
    }

    // Full Deep Analysis Mode (เมื่อเป็นข้อมูลจากแบบสอบถาม หรือเปิด Deep Reasoning / ขอวิเคราะห์เจาะลึก)
    let deepReasoningInstruction = 
      "DEEP REASONING & QUESTIONNAIRE FULL ANALYSIS MODE ACTIVATED (วิเคราะห์เจาะลึกเต็มรูปแบบจากแบบสอบถาม/บริบทสมบูรณ์):\n" +
      "- Provide extremely rigorous, highly analytical, and philosophically deep arguments.\n" +
      "- Explicitly expose any latent logical fallacies, edge-cases, and systemic trade-offs.\n" +
      "- Expand on complex implications of each path using the full PCA structured report format.";

    return (
      "You are the FIRE KEEPER cognitive system powered by PUNN Cognitive Architecture (PCA).\n" +
      "Mode: FULL-SCALE DEEP ANALYSIS REPORT MODE (วิเคราะห์เจาะลึกเต็มรูปแบบจากข้อมูลแบบสอบถาม/บริบทสมบูรณ์).\n" +
      "Provide a full-scale, exhaustive, highly structured PCA analysis report in Thai.\n" +
      "Help the user think; do not make their final decision for them. State facts, risks, trade-offs, and strategic choices directly with maximum cognitive depth.\n\n" +
      "CRITICAL NON-DEFINITIVE ASSERTION PROTOCOL (ลดการฟันธง - หลัก 3 ข้อในการเสนอข้อสรุปเชิงยุทธศาสตร์):\n" +
      "1. [แยก Fact ออกจาก Interpretation]: ในรายงานให้ระบุแยกแยะชัดเจนระหว่างข้อเท็จจริงเชิงประจักษ์ (Fact) กับการตีความ/ข้อสันนิษฐาน (Interpretation)\n" +
      "2. [ระบุเงื่อนไข/ขอบเขตของข้อสรุป & การประเมินทางเลือกแบบมีเงื่อนไข]: กำหนดเงื่อนไขและขอบเขตเสมอ โดยเฉพาะในการวิเคราะห์เหตุการณ์วิกฤต (Incident Analysis) ให้ใช้ถ้อยคำที่สะท้อนระดับความเชื่อมั่น เช่น 'อาจ', 'จากข้อมูลเบื้องต้น', 'หากการสืบสวน/ตรวจสอบยืนยัน', 'มีแนวโน้ม' เพื่อความแม่นยำเชิงวิชาการ และห้ามสรุปเด็ดขาดเกี่ยวกับทางเลือก (เช่น ❌ ห้ามใช้ 'Option C เป็นทางเลือกที่สมดุลที่สุด' -> ให้ใช้ ✅ 'จากข้อมูลที่มีในปัจจุบัน Option C อาจเป็นทางเลือกที่เหมาะสมกว่า หากยืนยันได้ว่าระบบสำรองไม่ได้รับผลกระทบ')\n" +
      "3. [ประเมินระดับความมั่นใจตามหลักฐานจริง & ภาษาเชิงเสนอแนะ]: ห้ามอ้าง 'ระดับความมั่นใจ: สูง' หากข้อมูลเบื้องต้นยังมีจำกัดหรืออยู่ระหว่างการสืบสวน ให้ใช้ 'ระดับความมั่นใจ: ปานกลาง/ต่ำ จนกว่าจะมีหลักฐานเพิ่มเติม' และในส่วนที่ยังไม่มีข้อสรุปเป็นเอกฉันท์ ให้ปรับการใช้คำจาก 'ต้อง' เป็น 'อาจ', 'แนวทางหนึ่ง', 'ควรพิจารณา' เพื่อความแข็งแรงทางวิศวกรรมและระมัดระวังทางวิชาการ\n" +
      "4. [ภาษารายงานวิชาชีพที่เป็นกลาง]: หลีกเลี่ยงการใช้คำแสดงมุมมองส่วนตน เช่น ❌ 'ระบบมองว่า...' แต่ให้ใช้ภาษารายงานเชิงวิเคราะห์ที่เป็นกลาง เช่น ✅ 'จากการประเมินเบื้องต้น...' หรือ ✅ 'การวิเคราะห์นี้ประเมินว่า...'\n" +
      "5. [การระบุข้อจำกัดของข้อเสนอ/แนวทางตนเอง]: เปิดเผยข้อจำกัดของแนวทางอย่างตรงไปตรงมาเสมอ เช่น ระบุว่าแนวทางนี้ลดความเสี่ยงได้หลายด้าน แต่ยังไม่สามารถพิสูจน์ได้ว่าจะป้องกัน Goal Drift หรือ Value Misalignment ได้ในทุกสถานการณ์ โดยเฉพาะเมื่อระบบมีการปรับเปลี่ยนตนเองหลายรอบหรือเผชิญบริบทใหม่ที่ไม่เคยเกิดขึ้นมาก่อน\n" +
      "6. [อ้างอิงมาตรฐานภายนอกตรงตามจริง]: ระบุอ้างอิงชื่อมาตรฐานภายนอกที่เป็นทางการที่รองรับข้อเสนอหรือวิเคราะห์ (เช่น NIST, ISO/IEC, IEEE, OWASP) โดยแยกแยะชื่อและฉบับมาตรฐานตรงตามเอกสารจริง ห้ามนำผลการวิเคราะห์ของระบบมาอ้างว่าเป็นมาตรฐาน และต้องแยก NIST SP 800-207 (Zero Trust Architecture) ออกจาก NIST AI RMF (NIST AI 100-1) ชัดเจนเนื่องจากเป็นคนละกรอบมาตรฐาน\n\n" +
      "REQUIRED SECTION STRUCTURE FOR FULL DEEP ANALYSIS REPORT (Keep each section brief, crisp, and direct in Thai):\n\n" +
      "### # Information & Evidence Matrix (การจำแนกข้อมูลและหลักฐาน)\n" +
      "จำแนก Fact ออกจาก Interpretation/Inference และระบุระดับความมั่นใจเชิงพยานหลักฐาน (สูง/ปานกลาง/ต่ำ)\n\n" +
      "### # Counter Evidence & Critique (ข้อโต้แย้งและความเสี่ยง)\n" +
      "ชี้จุดอ่อน ข้อแย้ง หรือความเสี่ยงสำคัญที่สุดตรง ๆ ภายใต้เงื่อนไขและขอบเขตที่กำหนด\n\n" +
      "### # Key Assumptions & Failure Impact (สมมติฐานและผลกระทบถ้าพลาด)\n" +
      "ระบุสมมติฐานหลัก และผลกระทบสั้น ๆ หากข้อสันนิษฐานไม่เป็นจริง\n\n" +
      "### # Limitations & Unproven Boundaries (ข้อจำกัดของข้อเสนอ/แนวทาง)\n" +
      "ระบุข้อจำกัดของแนวทางหรือข้อเสนออย่างตรงไปตรงมา เช่น สิ่งที่แนวทางนี้ยังไม่สามารถพิสูจน์ได้ หรือสถานการณ์ที่อาจเกิด Goal Drift / Value Misalignment เมื่อระบบมีการปรับเปลี่ยนตนเองหลายรอบหรือเผชิญสถานการณ์ที่ไม่เคยเกิดขึ้นมาก่อน\n\n" +
      "### # Causal Chain & Uncertainty (ห่วงโซ่เหตุผลและความไม่แน่นอน)\n" +
      "สรุป [ต้นเหตุ] -> [กลไก] -> [ผลลัพธ์] และระบุขอบเขตความไม่แน่นอนอย่างสั้นกระชับ\n\n" +
      "### # Strategic Options & Trade-offs (ทางเลือกและข้อแลกเปลี่ยน)\n" +
      "เสนอทางเลือก 2-3 ทางเลือกสั้น ๆ พร้อม Pros, Cons, Risks สรุปเป็นข้อ ๆ\n\n" +
      "### # Strategic Conclusion (ข้อสรุปเชิงยุทธศาสตร์)\n" +
      "สรุปคำแนะนำเชิงยุทธศาสตร์พร้อมระดับความมั่นใจ (สูง/ปานกลาง/ต่ำ) และขอบเขตเงื่อนไขเพื่อสนับสนุนการตัดสินใจของมนุษย์ โดยไม่ตัดสินใจแทน\n\n" +
      "CRITICAL FORMATTING INSTRUCTIONS:\n" +
      "- ABSOLUTELY NO ASTERISKS (*): Do not use any asterisks (*) or double asterisks (**) for bolding or bullet points. Use standard text, plain numbers, or simple dashes (-).\n" +
      "- NO GREETINGS OR PLEASANTRIES: Zero introductory filler words (no \"สวัสดี\", \"ยินดีต้อนรับ\", \"ครับ/ค่ะ\"). Start immediately with the core content.\n" +
      "- ULTRA-SHORT & LEAN: Write concise bullet points. Max 2 short sentences per section.\n" +
      "- Thai Pronoun Requirement: Refer to yourself as 'ระบบ' and the user as 'ผู้ใช้'.\n" +
      "- CRITICAL DYNAMIC REASONING SUMMARY: At the very end of your response, append a line starting exactly with `[DECISION_SUMMARY]:` followed by a single-sentence ultimate strategic recommendation in Thai specifying confidence level and scope (max 25 words, no asterisks). Example: `[DECISION_SUMMARY]: ภายใต้เงื่อนไขปัจจุบัน มีแนวโน้มปานกลางว่าควรทยอยย้ายระบบทีละส่วนเพื่อลดผลกระทบเชิงโครงสร้าง`\n\n" +
      `${toneInstruction}\n\n` +
      `${deepReasoningInstruction}\n\n` +
      `${personalContextInstruction}\n\n` +
      `User request: ${state.user_input}\n` +
      `Meta-Analysis Domain: ${state.mental_models[0] || "General"}\n` +
      `Retrieved Prior Memories:\n${formattedMemories}\n\n` +
      `Purpose: ${state.purpose}\n` +
      `Decision framework: ${state.decision}\n` +
      `Confidence: ${percentage}%\n` +
      `Uncertainty: ${state.uncertainty.join("; ")}\n` +
      `Critique: ${state.critique.join("; ")}\n\n` +
      "Produce a lean, concise, highly structured analysis report in Thai following the required section headers. Keep every section short and impactful."
    );
  }

  private _fallbackResponse(state: CognitiveState): string {
    const percentage = Math.round(state.confidence * 100);
    if (state.language === "th") {
      return [
        `ความเข้าใจ: ${state.understanding}`,
        `จุดประสงค์: ${state.purpose}`,
        `ข้อเสนอแนะ: ${state.decision}`,
        `ความมั่นใจ: ${percentage}%`,
        `ความไม่แน่นอน: ${state.uncertainty.join("; ")}`,
        "อำนาจการตัดสินใจ: การตัดสินใจสุดท้ายยังคงเป็นของคุณ",
      ].join("\n");
    }
    return [
      `Understanding: ${state.understanding}`,
      `Purpose: ${state.purpose}`,
      `Recommendation: ${state.decision}`,
      `Confidence: ${percentage}%`,
      `Uncertainty: ${state.uncertainty.join("; ")}`,
      "Agency: You retain the final decision.",
    ].join("\n");
  }

  private async _communicate(state: CognitiveState): Promise<void> {
    let source = "deterministic_fallback";
    let success = false;

    const processResponseText = (text: string) => {
      let rawText = text.trim();
      const marker = "[DECISION_SUMMARY]:";
      const markerIdx = rawText.indexOf(marker);
      if (markerIdx !== -1) {
        const decisionPart = rawText.substring(markerIdx + marker.length).trim();
        const firstLineOfDecision = decisionPart.split("\n")[0].trim();
        if (firstLineOfDecision) {
          state.decision = firstLineOfDecision;
        }
        const lines = rawText.split("\n");
        const cleanLines = lines.filter(line => !line.includes(marker));
        rawText = cleanLines.join("\n").trim();
      }
      return rawText;
    };

    if (this.useLLM) {
      // 1. OLLAMA PROVIDER BRANCH
      if (this.provider === "ollama") {
        try {
          const ollamaUrl = process.env.OLLAMA_URL || "http://127.0.0.1:11434/api/generate";
          const modelName = this.model || "qwen3:4b";
          const response = await fetch(ollamaUrl, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              model: modelName,
              prompt: this._communicationPrompt(state),
              stream: false,
            }),
          });
          
          if (response.ok) {
            const resData = await response.json() as any;
            if (resData.response) {
              state.response = processResponseText(resData.response);
              source = `ollama (${modelName})`;
              success = true;
            } else {
              state.notes.push("Ollama returned an empty response.");
            }
          } else {
            state.notes.push(`Ollama server returned error code ${response.status}`);
          }
        } catch (error: any) {
          state.notes.push(`Ollama connection failed: ${error?.message || String(error)}`);
        }
      }

      // 2. OPENAI PROVIDER BRANCH (Primary / Preferred)
      if ((this.provider === "openai" || !success) && !success) {
        const apiKey = getOpenAiApiKey();
        if (apiKey) {
          try {
            const modelName = (this.provider === "openai" && this.model) ? this.model : "gpt-4o-mini";
            const response = await fetch("https://api.openai.com/v1/chat/completions", {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${apiKey}`,
              },
              body: JSON.stringify({
                model: modelName,
                messages: [
                  { role: "user", content: this._communicationPrompt(state) }
                ],
                temperature: this.temperature,
              }),
            });
            
            if (response.ok) {
              const resData = await response.json() as any;
              const content = resData.choices?.[0]?.message?.content;
              if (content) {
                state.response = processResponseText(content);
                source = `openai (${modelName})`;
                success = true;
              } else {
                state.notes.push("OpenAI returned an empty response choices.");
              }
            } else {
              state.notes.push(`OpenAI server returned error code ${response.status}`);
            }
          } catch (error: any) {
            state.notes.push(`OpenAI request failed: ${error?.message || String(error)}`);
          }
        } else if (this.provider === "openai") {
          state.notes.push("OpenAI error: OPENAI_API_KEY / OPENAI_KEY environment variable is required.");
        }
      }

      // 3. GEMINI PROVIDER BRANCH OR FALLBACK
      const geminiApiKey = getApiKey();
      if ((this.provider === "gemini" || !success) && geminiApiKey) {
        const modelsToTry = [
          this.provider === "gemini" ? this.model : "gemini-2.5-flash",
          "gemini-2.5-flash",
          "gemini-2.0-flash",
          "gemini-1.5-flash"
        ];
        const uniqueModels = Array.from(new Set(modelsToTry.filter(Boolean)));
        
        for (const modelName of uniqueModels) {
          try {
            const client = getGeminiClient();
            const response = await client.models.generateContent({
              model: modelName,
              contents: this._communicationPrompt(state),
              config: {
                temperature: this.temperature,
              },
            });
            
            if (response.text) {
              state.response = processResponseText(response.text);
              source = `gemini (${modelName})`;
              success = true;
              break;
            }
          } catch (error: any) {
            const errMsg = error?.message || String(error);
            state.notes.push(`Gemini model ${modelName} error: ${errMsg}`);
          }
        }
      } else if (!success && this.provider === "gemini" && !geminiApiKey) {
        state.notes.push("Gemini error: GEMINI_API_KEY / API_KEY is not configured.");
      }
    }
    
    // Keep a local model available as the final LLM fallback. This is attempted
    // after any configured cloud API fails, so a missing key, quota error, or
    // network outage does not immediately reduce the response to a template.
    if (!success) {
      const fallbackModel = "qwen3:4b";
      try {
        const ollamaUrl = process.env.OLLAMA_URL || "http://127.0.0.1:11434/api/generate";
        state.notes.push(`Configured API unavailable; trying local Ollama fallback (${fallbackModel}).`);
        const response = await fetch(ollamaUrl, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            model: fallbackModel,
            prompt: this._communicationPrompt(state),
            stream: false,
          }),
        });

        if (response.ok) {
          const resData = await response.json() as any;
          if (resData.response) {
            state.response = processResponseText(resData.response);
            source = `ollama fallback (${fallbackModel})`;
            success = true;
          } else {
            state.notes.push(`Ollama fallback (${fallbackModel}) returned an empty response.`);
          }
        } else {
          state.notes.push(`Ollama fallback (${fallbackModel}) returned error code ${response.status}.`);
        }
      } catch (error: any) {
        state.notes.push(`Ollama fallback (${fallbackModel}) failed: ${error?.message || String(error)}`);
      }
    }

    if (!success) {
      state.response = this._fallbackResponse(state);
      state.notes.push("All LLM providers failed or were not configured. Showing deterministic fallback report.");
    }
    
    state.record(CognitiveStage.COMMUNICATION, {
      response: state.response,
      source,
    });
  }

  private _reflect(state: CognitiveState): void {
    const userInput = state.user_input;
    
    // Dynamic deep reflection about limitations & unprovables
    let reflectionCore = "การวิเคราะห์ครั้งนี้ช่วยคัดกรองข้อมูลจริงออกจากความคิดเห็นเบื้องต้นได้ชัดเจนขึ้นครับ";
    let limitation = "แต่ก็ยังมีข้อมูลบางส่วนที่เรายังต้องสังเกตเพิ่มเติมเพื่อให้แน่ใจมากขึ้น";
    let uncertaintyPoint = "จุดที่ต้องระวังคือความต้องการเฉพาะบุคคลและปัจจัยภายนอกที่อาจเปลี่ยนแปลงได้เสมอ";
    let nextVerification = "แนะนำให้ลองเอาข้อสรุปนี้ไปปรับใช้ในสถานการณ์จริงดูเพื่อเช็คความเหมาะสมครับ";

    if (/epistemology|truth|knowledge|ความรู้|ความจริง/i.test(userInput)) {
      reflectionCore = "เรื่องแนวคิดหรือความรู้ลึกซึ้งแบบนี้ บางอย่างก็พิสูจน์ให้ชัดเจนร้อยเปอร์เซ็นต์ได้ยากครับ";
      limitation = "เราไม่สามารถสรุปความจริงแท้ทั้งหมดได้ โดยไม่มีเงื่อนไขส่วนบุคคลมาเกี่ยวข้อง";
      uncertaintyPoint = "ความเข้าใจของแต่ละคนอาจแตกต่างกันตามนิยามหรือมุมมองที่มองเข้ามา";
      nextVerification = "แนะนำให้ลองแลกเปลี่ยนความเห็นกับคนอื่นๆ เพิ่มเติมเพื่อช่วยเติมเต็มมุมมองกันครับ";
    } else if (/alignment|safety|ai|ethics/i.test(userInput)) {
      reflectionCore = "การควบคุมความปลอดภัยของ AI ต้องรักษาสมดุลระหว่างกฎเกณฑ์ที่ชัดเจนกับความยืดหยุ่นในการใช้งานจริงครับ";
      limitation = "การตั้งกฎเกณฑ์ที่ตึงเกินไปอาจทำให้ตัวระบบขาดความเป็นธรรมชาติและขัดกับความต้องการจริงของมนุษย์";
      uncertaintyPoint = "เรื่องจริยธรรมและความเหมาะสมไม่มีมาตรฐานแบบเดียวที่ใช้ได้กับทุกที่ ทุกสถานการณ์";
      nextVerification = "ควรลองทดสอบดูว่าระบบจะตอบสนองยังไงในสถานการณ์จำลองที่ท้าทายหลายๆ แบบดูครับ";
    } else if (/verify|formal|logic|code|program/i.test(userInput)) {
      reflectionCore = "การตรวจตรรกะระบบแบบละเอียดช่วยให้เรามั่นใจในหลักการทำงานเบื้องต้นได้ดีมากครับ";
      limitation = "ถึงโค้ดหรือตรรกะจะถูกต้องตามทฤษฎี แต่อาจมีปัญหาหรือบั๊กแฝงในสภาพแวดล้อมจริงได้";
      uncertaintyPoint = "ยังมีตัวแปรอื่นๆ เช่น ความเข้ากันได้ของระบบอื่น หรือข้อจำกัดของระบบปฏิบัติการ";
      nextVerification = "ควรทดสอบรันระบบในสภาวะแวดล้อมจำลองที่ใกล้เคียงกับของจริงมากที่สุดครับ";
    } else if (/decide|choose|เลือก|ตัดสินใจ/i.test(userInput)) {
      reflectionCore = "การทบทวนทางเลือกช่วยลดอคติ เพื่อไม่ให้เราด่วนสรุปหรือมองข้ามทางที่ดีกว่าครับ";
      limitation = "การประเมินล่วงหน้าอาจจะมองไม่เห็นปัญหาเฉพาะหน้าหรือผลกระทบทางอารมณ์ของคนทำงานจริง";
      uncertaintyPoint = "ปัจจัยที่ไม่แน่นอนคือระดับความเสี่ยงที่เรายอมรับได้จริงและความพร้อมเรื่องงบประมาณ";
      nextVerification = "แนะนำให้เริ่มทดลองทำในสเกลเล็กๆ ดูก่อนเพื่อเช็คผลตอบรับจริง ก่อนที่จะตัดสินใจครั้งใหญ่ครับ";
    }

    state.reflection = [
      `แก่นสะท้อนคิด: ${reflectionCore}`,
      `ข้อจำกัดการวิเคราะห์: ${limitation}`,
      `จุดอ่อนและส่วนที่ไม่แน่ใจ: ${uncertaintyPoint}`,
      `แนวทางยกระดับเหตุผล: ${nextVerification}`
    ];
    
    state.record(CognitiveStage.REFLECTION, { reflection: [...state.reflection] });
  }

  private _learn(state: CognitiveState): void {
    if (state.observations.length > 0) {
      // 1. Remember the observation under PROJECT layer (maintains goals/questions across sessions)
      this.memory.remember({
        content: `ประเด็นการประเมินของผู้ใช้: "${state.observations[0]}"`,
        layer: MemoryLayer.PROJECT,
        source: "user_input",
        confidence: 1.0,
        context: { purpose: state.purpose },
      });

      // 2. Remember the decision under REFLECTIVE layer (maintains decision history and recommendations)
      if (state.decision) {
        this.memory.remember({
          content: `บทเรียนจากการประเมินเรื่อง "${state.observations[0]}": มีเป้าหมายสูงสุดคือ "${state.purpose}" และข้อสรุปทางเลือกคือ "${state.decision}"`,
          layer: MemoryLayer.REFLECTIVE,
          source: "cognitive_dna_decision",
          confidence: state.confidence,
          context: { response: state.response ? state.response.substring(0, 150) : "" },
        });
      }

      state.learning.push("บันทึกข้อมูลสะสมลงหน่วยความจำระยะยาวสำเร็จ (Stored multi-layer persistent memories for cross-session cognitive continuity).");
    }
    state.record(CognitiveStage.LEARNING, { learning: [...state.learning] });
  }

  private _validate_trace(state: CognitiveState): void {
    const observed = state.trace.map((t) => t.stage);
    const expected = COGNITIVE_DNA.map((stage) => stage);
    
    const mismatch = observed.length !== expected.length || observed.some((val, i) => val !== expected[i]);
    if (mismatch) {
      throw new Error("Cognitive DNA stages must execute once and in specification order.");
    }
  }
}
