import * as fs from "fs";
import * as path from "path";

export enum MemoryLayer {
  WORKING = "working",
  SESSION = "session",
  PROJECT = "project",
  SEMANTIC = "semantic",
  PROCEDURAL = "procedural",
  REFLECTIVE = "reflective",
}

export interface MemoryItem {
  id?: string;
  content: string;
  layer: MemoryLayer;
  source: string;
  confidence: number;
  confidenceHistory?: number[];
  createdByStage?: string;
  usedInConversations?: string[];
  context: Record<string, string>;
  created_at: string;
}

const MEMORY_FILE_PATH = path.join(process.cwd(), "memory_store.json");

export class MemoryEngine {
  private _items: MemoryItem[] = [];

  constructor() {
    this.loadMemory();
  }

  private loadMemory() {
    try {
      if (fs.existsSync(MEMORY_FILE_PATH)) {
        const data = fs.readFileSync(MEMORY_FILE_PATH, "utf-8");
        const parsed = JSON.parse(data);
        if (Array.isArray(parsed)) {
          this._items = parsed.map((item, idx) => ({
            ...item,
            id: item.id || `Memory #${idx + 1}`,
            confidenceHistory: item.confidenceHistory || [item.confidence || 0.72],
            createdByStage: item.createdByStage || "LEARNING",
            usedInConversations: item.usedInConversations || [],
          }));
          console.log(`[MemoryEngine] Loaded ${this._items.length} memory items from disk.`);
        }
      }
    } catch (error) {
      console.error("[MemoryEngine] Failed to load memory from disk:", error);
    }
  }

  private saveMemory() {
    try {
      fs.writeFileSync(MEMORY_FILE_PATH, JSON.stringify(this._items, null, 2), "utf-8");
    } catch (error) {
      console.error("[MemoryEngine] Failed to save memory to disk:", error);
    }
  }

  remember(item: Partial<MemoryItem> & { content: string; layer: MemoryLayer; source: string }): MemoryItem {
    const nextNum = this._items.length + 1;
    const initialConf = item.confidence ?? 0.72;
    const fullItem: MemoryItem = {
      id: item.id || `Memory #${nextNum}`,
      content: item.content,
      layer: item.layer,
      source: item.source,
      confidence: initialConf,
      confidenceHistory: item.confidenceHistory || [initialConf],
      createdByStage: item.createdByStage || "LEARNING",
      usedInConversations: item.usedInConversations || [],
      context: item.context ?? {},
      created_at: item.created_at ?? new Date().toISOString(),
    };
    this._items.push(fullItem);
    this.saveMemory();
    return fullItem;
  }

  recordUsage(memoryId: string, conversationTag: string, newConfidence?: number): void {
    const item = this._items.find((m) => m.id === memoryId || m.content === memoryId);
    if (item) {
      if (!item.usedInConversations) item.usedInConversations = [];
      if (!item.usedInConversations.includes(conversationTag)) {
        item.usedInConversations.push(conversationTag);
      }
      if (newConfidence !== undefined) {
        if (!item.confidenceHistory) item.confidenceHistory = [item.confidence];
        item.confidenceHistory.push(newConfidence);
        item.confidence = newConfidence;
      }
      this.saveMemory();
    }
  }

  getAllItems(): MemoryItem[] {
    return this._items;
  }

  deleteItem(content: string): boolean {
    const initialLen = this._items.length;
    this._items = this._items.filter(item => item.content !== content);
    if (this._items.length !== initialLen) {
      this.saveMemory();
      return true;
    }
    return false;
  }

  clearMemory(): void {
    this._items = [];
    this.saveMemory();
  }

  retrieve(query: string, limit: number = 5): MemoryItem[] {
    const queryLower = query.trim().toLowerCase();
    if (!queryLower || queryLower.length < 3) {
      return [];
    }

    // Stopwords in Thai and English that pollute relevance
    const STOPWORDS = new Set([
      "การ", "ความ", "ช่วย", "วิเคราะห์", "ประเมิน", "ผู้ใช้", "เกี่ยวกับ", "เรื่อง", "ของ", "ใน", "และ", "หรือ",
      "กับ", "เป็น", "ให้", "มี", "ได้", "จะ", "ที่", "เพื่อ", "ไหม", "ดี", "จริง", "อยาก", "สอบถาม", "ช่วยวิเคราะห์",
      "ช่วยจัดเรียง", "ทางเลือก", "ข้อสรุป", "ประเด็น", "บทเรียน", "เป้าหมาย", "สูงสุด", "ตัดสินใจ", "อย่าง", "รอบคอบ",
      "ตนเอง", "ควร", "อะไร", "อย่างไร", "ไหน", "หรือไม", "หรือไม่", "ครับ", "ค่ะ", "ด้วย", "ตอนนี้", "ปีนี้", "ไหมครับ",
      "ไหมค่ะ", "ทำไม", "อย่างไรดี", "แนะนำ", "ให้หน่อย", "หน่อย", " purpose", "response", "user_input", "learning",
      "confidence", "context", "the", "a", "an", "is", "are", "was", "were", "to", "for", "of", "and", "or", "in", "on"
    ]);

    // Extract English technical terms (e.g. AI, Microservices, Monolith, SQL, NoSQL, EV, BYOD)
    const englishTerms = (queryLower.match(/[a-z0-9\-]{2,}/gi) || [])
      .filter(t => !STOPWORDS.has(t) && t.length >= 2);

    // Extract Thai core content keywords (removing common prefixes and stopwords)
    const thaiClean = queryLower.replace(/[a-z0-9]/gi, " ");
    const rawThaiTokens = (thaiClean.match(/[\u0E00-\u0E7F]{2,}/g) || []);
    const thaiKeywords: string[] = [];
    
    for (const token of rawThaiTokens) {
      if (STOPWORDS.has(token)) continue;
      // Extract sub-tokens if continuous string
      if (token.length > 8) {
        // Break into 3-4 character sliding n-grams for Thai compound matching
        for (let i = 0; i <= token.length - 4; i += 3) {
          const sub = token.substring(i, i + 4);
          if (!STOPWORDS.has(sub)) thaiKeywords.push(sub);
        }
      } else {
        thaiKeywords.push(token);
      }
    }

    const queryTopicKeywords = Array.from(new Set([...englishTerms, ...thaiKeywords]));

    if (queryTopicKeywords.length === 0) {
      // If query has no distinct domain topic words, return empty to prevent arbitrary matches
      return [];
    }

    const ranked: Array<{ score: number; item: MemoryItem; matches: string[] }> = [];

    for (const item of this._items) {
      // Analyze item content and context (excluding generic purpose templates)
      const contentLower = item.content.toLowerCase();
      const contextLower = JSON.stringify(item.context || {}).toLowerCase();
      const fullText = `${contentLower} ${contextLower}`;

      let matchCount = 0;
      const matchedTokens: string[] = [];

      for (const keyword of queryTopicKeywords) {
        if (fullText.includes(keyword)) {
          matchCount++;
          matchedTokens.push(keyword);
        }
      }

      if (matchCount === 0) continue;

      // Calculate strict relevance score
      const matchRatio = matchCount / queryTopicKeywords.length;
      let score = matchRatio * 1.5 + (matchCount * 0.4) * (item.confidence || 0.7);

      // High bonus for exact English technical term match (e.g., both mention "microservices" or "nosql")
      for (const eng of englishTerms) {
        if (fullText.includes(eng)) {
          score += 1.2;
        }
      }

      // Exact long phrase containment bonus
      if (contentLower.includes(queryLower)) {
        score += 3.0;
      }

      // STRICT RELEVANCE THRESHOLD: Must have score >= 0.85 and at least 1 distinct topic keyword match
      if (score >= 0.85 && matchedTokens.length >= 1) {
        ranked.push({ score, item, matches: matchedTokens });
      }
    }

    // Sort descending by score, then recency
    ranked.sort((a, b) => {
      if (Math.abs(b.score - a.score) > 0.01) {
        return b.score - a.score;
      }
      return new Date(b.item.created_at).getTime() - new Date(a.item.created_at).getTime();
    });

    return ranked.slice(0, limit).map((entry) => entry.item);
  }
}
