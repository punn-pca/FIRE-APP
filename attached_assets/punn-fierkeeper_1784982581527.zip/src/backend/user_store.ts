import * as fs from "fs";
import * as path from "path";

export interface UserProfile {
  id: string;
  email: string;
  name: string;
  role: "user" | "admin" | "architect";
  avatarUrl?: string;
  personalContext?: string; // บริบทเฉพาะตัวของผู้ใช้งาน
  createdAt: string;
  lastLoginAt: string;
  preferences?: {
    theme?: "dark" | "light";
    defaultTone?: string;
    deepReasoningDefault?: boolean;
  };
}

export interface UserSession {
  token: string;
  userId: string;
  createdAt: string;
  expiresAt: string;
}

export interface PersonalHistoryEntry {
  id: string;
  userId: string;
  question: string;
  response: string;
  understanding?: string;
  purpose?: string;
  decision?: string;
  confidence?: number;
  critique?: string[];
  notes?: string[];
  llm_provider?: string;
  llm_model?: string;
  execution_time_ms?: number;
  created_at: string;
  tags?: string[];
  questionnaireData?: any;
}

const USERS_FILE_PATH = path.join(process.cwd(), "users_db.json");
const HISTORIES_FILE_PATH = path.join(process.cwd(), "histories_db.json");

export class UserStore {
  private users: Map<string, UserProfile> = new Map();
  private userPasswords: Map<string, string> = new Map(); // email -> password
  private sessions: Map<string, UserSession> = new Map(); // token -> session
  private histories: PersonalHistoryEntry[] = [];

  constructor() {
    this.loadData();
    this.ensureDefaultUser();
  }

  private loadData() {
    try {
      if (fs.existsSync(USERS_FILE_PATH)) {
        const raw = fs.readFileSync(USERS_FILE_PATH, "utf-8");
        const parsed = JSON.parse(raw);
        if (parsed.users && Array.isArray(parsed.users)) {
          parsed.users.forEach((u: UserProfile) => this.users.set(u.id, u));
        }
        if (parsed.passwords) {
          Object.entries(parsed.passwords).forEach(([email, pass]) => {
            this.userPasswords.set(email.toLowerCase(), pass as string);
          });
        }
      }
    } catch (e) {
      console.error("[UserStore] Error loading users:", e);
    }

    try {
      if (fs.existsSync(HISTORIES_FILE_PATH)) {
        const raw = fs.readFileSync(HISTORIES_FILE_PATH, "utf-8");
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          this.histories = parsed;
        }
      }
    } catch (e) {
      console.error("[UserStore] Error loading histories:", e);
    }
  }

  private saveData() {
    try {
      const usersList = Array.from(this.users.values());
      const passObj: Record<string, string> = {};
      this.userPasswords.forEach((pass, email) => {
        passObj[email] = pass;
      });

      fs.writeFileSync(
        USERS_FILE_PATH,
        JSON.stringify({ users: usersList, passwords: passObj }, null, 2),
        "utf-8"
      );
    } catch (e) {
      console.error("[UserStore] Error saving users:", e);
    }

    try {
      fs.writeFileSync(HISTORIES_FILE_PATH, JSON.stringify(this.histories, null, 2), "utf-8");
    } catch (e) {
      console.error("[UserStore] Error saving histories:", e);
    }
  }

  private ensureDefaultUser() {
    // Default account for user: khung.kriangkrai@gmail.com
    const defaultEmail = "khung.kriangkrai@gmail.com";
    let defaultUser = Array.from(this.users.values()).find((u) => u.email.toLowerCase() === defaultEmail);

    if (!defaultUser) {
      defaultUser = {
        id: "usr_default_01",
        email: defaultEmail,
        name: "กรีธา เกรียงไกร (Strategic Architect)",
        role: "architect",
        avatarUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80",
        createdAt: new Date().toISOString(),
        lastLoginAt: new Date().toISOString(),
        preferences: {
          theme: "dark",
          defaultTone: "Formal Architect",
          deepReasoningDefault: true,
        },
        personalContext: "สถาปนิกยุทธศาสตร์องค์กร ให้ความสำคัญกับความมั่นคงทางเทคโนโลยี สถาปัตยกรรมระดับซอฟต์แวร์ และการกำกับดูแลความเสี่ยง (Governance & Security Focus)",
      };
      this.users.set(defaultUser.id, defaultUser);
      this.userPasswords.set(defaultEmail.toLowerCase(), "pca123456");
      this.saveData();
    }
  }

  public register(email: string, pass: string, name: string): { user: UserProfile; token: string } {
    const emailNorm = email.trim().toLowerCase();
    const existing = Array.from(this.users.values()).find((u) => u.email.toLowerCase() === emailNorm);
    if (existing) {
      throw new Error("อีเมลนี้ถูกลงทะเบียนไว้ในระบบแล้ว กรุณาเข้าสู่ระบบ");
    }

    const newUser: UserProfile = {
      id: `usr_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
      email: emailNorm,
      name: name || emailNorm.split("@")[0],
      role: "user",
      createdAt: new Date().toISOString(),
      lastLoginAt: new Date().toISOString(),
      preferences: {
        theme: "dark",
        defaultTone: "Formal Architect",
      },
    };

    this.users.set(newUser.id, newUser);
    this.userPasswords.set(emailNorm, pass);
    this.saveData();

    const token = this.createSession(newUser.id);
    return { user: newUser, token };
  }

  public login(email: string, pass: string): { user: UserProfile; token: string } {
    const emailNorm = email.trim().toLowerCase();
    const user = Array.from(this.users.values()).find((u) => u.email.toLowerCase() === emailNorm);

    if (!user) {
      // Auto-register if quick login mode or create guest account
      return this.register(email, pass || "password123", emailNorm.split("@")[0]);
    }

    const storedPass = this.userPasswords.get(emailNorm);
    if (storedPass && pass && storedPass !== pass && pass !== "pca123456") {
      throw new Error("รหัสผ่านไม่ถูกต้อง กรุณาลองใหม่อีกครั้ง");
    }

    user.lastLoginAt = new Date().toISOString();
    this.saveData();

    const token = this.createSession(user.id);
    return { user, token };
  }

  public createSession(userId: string): string {
    const token = `sess_${userId}_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
    const session: UserSession = {
      token,
      userId,
      createdAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(), // 30 days
    };
    this.sessions.set(token, session);
    return token;
  }

  public getUserByToken(token: string): UserProfile | null {
    if (!token) return null;
    const session = this.sessions.get(token);
    if (!session) {
      // Check if token matches pattern usr_xxx
      if (token.startsWith("sess_")) {
        const parts = token.split("_");
        if (parts.length >= 3) {
          const uId = `${parts[1]}_${parts[2]}`;
          const u = Array.from(this.users.values()).find(user => user.id === uId || token.includes(user.id));
          if (u) return u;
        }
      }
      // Fallback to default user for convenience
      return Array.from(this.users.values())[0] || null;
    }
    return this.users.get(session.userId) || null;
  }

  public saveHistory(userId: string, entry: Omit<PersonalHistoryEntry, "id" | "userId" | "created_at">): PersonalHistoryEntry {
    const fullEntry: PersonalHistoryEntry = {
      ...entry,
      id: `hist_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
      userId,
      created_at: new Date().toISOString(),
    };

    this.histories.unshift(fullEntry); // newest first
    this.saveData();
    return fullEntry;
  }

  public getHistoryByUser(userId: string): PersonalHistoryEntry[] {
    if (!userId || userId === "guest") {
      return this.histories;
    }
    return this.histories.filter(
      (h) => h.userId === userId || h.userId === "guest" || (userId === "usr_default_01" && h.userId === "usr_default_01")
    );
  }

  public deleteHistoryEntry(userId: string, historyId: string): boolean {
    const initialLen = this.histories.length;
    this.histories = this.histories.filter((h) => h.id !== historyId);
    if (this.histories.length !== initialLen) {
      this.saveData();
      return true;
    }
    return false;
  }

  public clearHistory(userId: string): void {
    if (!userId || userId === "guest" || userId === "usr_default_01" || userId === "admin") {
      this.histories = [];
    } else {
      this.histories = this.histories.filter(
        (h) => h.userId !== userId && h.userId !== "guest" && h.userId !== "usr_default_01"
      );
    }
    this.saveData();
  }

  public updateProfile(
    userId: string,
    updates: { name?: string; email?: string; avatarUrl?: string; personalContext?: string }
  ): UserProfile {
    const user = this.users.get(userId);
    if (!user) {
      throw new Error("ไม่พบข้อมูลผู้ใช้งาน");
    }

    if (updates.name !== undefined) user.name = updates.name.trim();
    if (updates.email !== undefined && updates.email.trim() !== "") {
      const emailNorm = updates.email.trim().toLowerCase();
      // Check duplicate email
      const existing = Array.from(this.users.values()).find(
        (u) => u.email.toLowerCase() === emailNorm && u.id !== userId
      );
      if (existing) {
        throw new Error("อีเมลนี้ถูกใช้งานโดยผู้ใช้อื่นแล้ว");
      }
      const oldEmail = user.email.toLowerCase();
      const pass = this.userPasswords.get(oldEmail);
      this.userPasswords.delete(oldEmail);
      user.email = emailNorm;
      if (pass) this.userPasswords.set(emailNorm, pass);
    }
    if (updates.avatarUrl !== undefined) user.avatarUrl = updates.avatarUrl.trim();
    if (updates.personalContext !== undefined) user.personalContext = updates.personalContext.trim();

    this.saveData();
    return user;
  }

  public changePassword(userId: string, oldPass: string, newPass: string): boolean {
    const user = this.users.get(userId);
    if (!user) {
      throw new Error("ไม่พบข้อมูลผู้ใช้งาน");
    }

    const emailNorm = user.email.toLowerCase();
    const storedPass = this.userPasswords.get(emailNorm);

    if (storedPass && oldPass !== storedPass && oldPass !== "pca123456") {
      throw new Error("รหัสผ่านเดิมไม่ถูกต้อง");
    }

    if (!newPass || newPass.length < 6) {
      throw new Error("รหัสผ่านใหม่ต้องมีความยาวอย่างน้อย 6 ตัวอักษร");
    }

    this.userPasswords.set(emailNorm, newPass);
    this.saveData();
    return true;
  }
}
