import React, { useState } from "react";
import { History, Search, Trash2, RotateCcw, Download, Calendar, Cpu, Brain, CheckCircle2, ChevronRight, X, Sparkles } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export interface PersonalHistoryEntry {
  id: string;
  userId: string;
  question: string;
  response: string;
  understanding?: string;
  purpose?: string;
  decision?: string;
  confidence?: number;
  critique?: string[];
  notes?: string[];
  llm_provider?: string;
  llm_model?: string;
  execution_time_ms?: number;
  created_at: string;
  questionnaireData?: any;
}

interface PersonalHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  history: PersonalHistoryEntry[];
  onSelectSession: (entry: PersonalHistoryEntry) => void;
  onClearHistory: () => void;
  onDeleteEntry: (historyId: string) => void;
  isDarkMode: boolean;
  userName?: string;
}

export default function PersonalHistoryModal({
  isOpen,
  onClose,
  history,
  onSelectSession,
  onClearHistory,
  onDeleteEntry,
  isDarkMode,
  userName = "ผู้ใช้งาน",
}: PersonalHistoryModalProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedEntry, setSelectedEntry] = useState<PersonalHistoryEntry | null>(null);
  const [showClearConfirm, setShowClearConfirm] = useState(false);

  if (!isOpen) return null;

  const filteredHistory = history.filter((item) => {
    const term = searchTerm.toLowerCase();
    return (
      item.question.toLowerCase().includes(term) ||
      (item.response && item.response.toLowerCase().includes(term)) ||
      (item.decision && item.decision.toLowerCase().includes(term))
    );
  });

  const exportAsJson = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(history, null, 2));
    const downloadAnchor = document.createElement("a");
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `pca_personal_history_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          className={`w-full max-w-4xl h-[85vh] p-6 rounded-2xl border shadow-2xl flex flex-col relative overflow-hidden ${
            isDarkMode ? "bg-[#18191b] border-[#2f3135] text-white" : "bg-white border-gray-200 text-gray-900"
          }`}
        >
          {/* Header */}
          <div className="flex items-center justify-between pb-4 border-b border-gray-200 dark:border-gray-800 shrink-0">
            <div className="flex items-center gap-3">
              <div className="p-3 rounded-xl bg-orange-500/10 text-orange-500 border border-orange-500/20">
                <History className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-extrabold text-lg flex items-center gap-2">
                  <span>ประวัติการใช้งานส่วนบุคคล ({userName})</span>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-orange-500/20 text-orange-400 font-bold border border-orange-500/30">
                    {history.length} รายการ
                  </span>
                </h3>
                <p className={`text-xs ${isDarkMode ? "text-gray-400" : "text-gray-500"}`}>
                  ประวัติรายงานการประมวลผล 12 ขั้นตอน และข้อสรุปการตัดสินใจยุทธศาสตร์ที่บันทึกไว้
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={exportAsJson}
                disabled={history.length === 0}
                className={`p-2 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                  isDarkMode
                    ? "bg-[#222427] border-[#32353a] text-gray-300 hover:text-white"
                    : "bg-gray-50 border-gray-200 text-gray-700 hover:bg-gray-100"
                }`}
                title="ส่งออกประวัติเป็นไฟล์ JSON"
              >
                <Download className="w-4 h-4 text-orange-500" />
                <span className="hidden sm:inline">ส่งออก JSON</span>
              </button>

              <button
                onClick={onClose}
                className={`p-2 rounded-full transition-colors cursor-pointer ${
                  isDarkMode ? "hover:bg-gray-800 text-gray-400" : "hover:bg-gray-100 text-gray-500"
                }`}
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Search bar */}
          <div className="py-3 flex items-center gap-3 shrink-0">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3 top-3 text-gray-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="ค้นหาประวัติการวิเคราะห์จากคีย์เวิร์ด คำถาม หรือข้อสรุป..."
                className={`w-full pl-9 pr-3 py-2 rounded-xl text-xs font-medium border outline-none transition-all ${
                  isDarkMode
                    ? "bg-[#212326] border-[#32353a] text-white focus:border-orange-500"
                    : "bg-gray-50 border-gray-200 text-gray-900 focus:border-orange-500"
                }`}
              />
            </div>

            {showClearConfirm ? (
              <div className="flex items-center gap-2 px-3 py-1.5 bg-rose-500/10 border border-rose-500/30 rounded-xl shrink-0">
                <span className="text-xs font-bold text-rose-500">ล้างประวัติทั้งหมด?</span>
                <button
                  onClick={() => {
                    onClearHistory();
                    setSelectedEntry(null);
                    setShowClearConfirm(false);
                  }}
                  className="px-2.5 py-1 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-extrabold cursor-pointer transition-colors"
                >
                  ลบทั้งหมด
                </button>
                <button
                  onClick={() => setShowClearConfirm(false)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold cursor-pointer transition-colors ${
                    isDarkMode ? "bg-gray-700 hover:bg-gray-600 text-gray-200" : "bg-gray-200 hover:bg-gray-300 text-gray-700"
                  }`}
                >
                  ยกเลิก
                </button>
              </div>
            ) : (
              history.length > 0 && (
                <button
                  onClick={() => setShowClearConfirm(true)}
                  className="px-3 py-2 rounded-xl border border-rose-500/20 text-rose-400 hover:bg-rose-500/10 text-xs font-bold flex items-center gap-1.5 cursor-pointer shrink-0"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>ล้างประวัติทั้งหมด</span>
                </button>
              )
            )}
          </div>

          {/* Body content */}
          <div className="flex-1 min-h-0 grid grid-cols-1 md:grid-cols-12 gap-4 pt-2">
            {/* History List Left Pane */}
            <div className="md:col-span-5 overflow-y-auto space-y-2.5 pr-1">
              {filteredHistory.length === 0 ? (
                <div className="p-8 text-center text-xs text-gray-400 border border-dashed rounded-xl">
                  {searchTerm ? "ไม่พบประวัติการวิเคราะห์ที่ตรงกับการค้นหา" : "ยังไม่มีประวัติการใช้งานส่วนบุคคล"}
                </div>
              ) : (
                filteredHistory.map((item) => {
                  const isSelected = selectedEntry?.id === item.id;
                  return (
                    <div
                      key={item.id}
                      onClick={() => setSelectedEntry(item)}
                      className={`p-3.5 rounded-xl border transition-all cursor-pointer relative group ${
                        isSelected
                          ? isDarkMode
                            ? "bg-orange-500/10 border-orange-500/40 text-white shadow-md"
                            : "bg-orange-50 border-orange-300 text-gray-900 shadow-sm"
                          : isDarkMode
                          ? "bg-[#212326] border-[#2f3135] hover:border-gray-600 text-gray-300"
                          : "bg-gray-50 border-gray-200 hover:border-gray-300 text-gray-800"
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2 mb-1.5">
                        <span className="text-[10px] font-extrabold text-orange-500 flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {new Date(item.created_at).toLocaleDateString("th-TH", {
                            day: "numeric",
                            month: "short",
                            year: "numeric",
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                        </span>

                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            if (selectedEntry?.id === item.id) {
                              setSelectedEntry(null);
                            }
                            onDeleteEntry(item.id);
                          }}
                          className="opacity-0 group-hover:opacity-100 p-1 text-gray-400 hover:text-rose-400 transition-opacity"
                          title="ลบรายการนี้"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <h4 className="text-xs font-bold line-clamp-2 leading-relaxed mb-1">
                        {item.question}
                      </h4>

                      {item.decision && (
                        <p className={`text-[11px] line-clamp-1 ${isDarkMode ? "text-gray-400" : "text-gray-500"}`}>
                          💡 {item.decision}
                        </p>
                      )}
                    </div>
                  );
                })
              )}
            </div>

            {/* Selected Entry Detail Right Pane */}
            <div className={`md:col-span-7 border rounded-xl p-4 overflow-y-auto space-y-4 ${
              isDarkMode ? "bg-[#1f2124] border-[#2f3135] text-white" : "bg-gray-100/80 border-gray-300 text-gray-900"
            }`}>
              {selectedEntry ? (
                <div className="space-y-4">
                  <div className="flex items-center justify-between pb-2 border-b border-gray-200 dark:border-gray-800">
                    <span className="text-xs font-extrabold text-orange-500 flex items-center gap-1.5">
                      <Sparkles className="w-4 h-4" />
                      <span>รายละเอียดเซสชันยุทธศาสตร์</span>
                    </span>

                    <button
                      onClick={() => {
                        onSelectSession(selectedEntry);
                        onClose();
                      }}
                      className="px-3 py-1.5 rounded-lg bg-orange-500 hover:bg-orange-600 text-white font-extrabold text-xs shadow-md transition-all flex items-center gap-1.5 cursor-pointer"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>โหลดเซสชันนี้ขึ้นพื้นที่ทำงาน</span>
                    </button>
                  </div>

                  <div className="space-y-2">
                    <h5 className={`text-xs font-bold uppercase ${isDarkMode ? "text-gray-400" : "text-gray-600"}`}>โจทย์คำถาม:</h5>
                    <div className={`p-3 rounded-xl border text-xs font-extrabold leading-relaxed ${
                      isDarkMode ? "bg-[#18191b] border-gray-800 text-white" : "bg-white border-gray-300 text-gray-900 shadow-sm"
                    }`}>
                      {selectedEntry.question}
                    </div>
                  </div>

                  {selectedEntry.understanding && (
                    <div className="space-y-1">
                      <h5 className={`text-xs font-bold uppercase ${isDarkMode ? "text-gray-400" : "text-gray-600"}`}>ความเข้าใจโจทย์ (Understanding):</h5>
                      <p className={`text-xs leading-relaxed ${isDarkMode ? "text-gray-300" : "text-gray-800"}`}>
                        {selectedEntry.understanding}
                      </p>
                    </div>
                  )}

                  {selectedEntry.decision && (
                    <div className={`p-3 rounded-xl border text-xs space-y-1 ${
                      isDarkMode ? "bg-amber-500/10 border-amber-500/20 text-amber-300" : "bg-amber-50 border-amber-300 text-amber-950"
                    }`}>
                      <span className="font-extrabold text-amber-600 dark:text-amber-500 flex items-center gap-1">
                        <CheckCircle2 className="w-4 h-4" />
                        <span>ข้อสรุปและทางเลือกยุทธศาสตร์:</span>
                      </span>
                      <p className={`leading-relaxed font-semibold ${isDarkMode ? "text-amber-100" : "text-amber-900"}`}>
                        {selectedEntry.decision}
                      </p>
                    </div>
                  )}

                  <div className="space-y-2">
                    <h5 className={`text-xs font-bold uppercase ${isDarkMode ? "text-gray-400" : "text-gray-600"}`}>คำตอบการประมวลผลฉบับเต็ม:</h5>
                    <div className={`p-3.5 rounded-xl border text-xs leading-relaxed font-mono whitespace-pre-wrap max-h-60 overflow-y-auto ${
                      isDarkMode ? "bg-[#18191b] border-gray-800 text-gray-200" : "bg-white border-gray-300 text-gray-900 shadow-sm"
                    }`}>
                      {selectedEntry.response}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-center p-8 text-gray-400 space-y-2">
                  <Brain className="w-10 h-10 text-orange-500/40" />
                  <p className="text-xs font-semibold">เลือกรายการประวัติการวิเคราะห์ฝั่งซ้าย เพื่อดูรายละเอียดฉบับเต็ม</p>
                </div>
              )}
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
