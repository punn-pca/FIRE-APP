import React, { useState } from "react";
import { User, Mail, Lock, LogIn, UserPlus, Sparkles, CheckCircle2, ShieldCheck, X } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface UserProfile {
  id: string;
  email: string;
  name: string;
  role: string;
  avatarUrl?: string;
}

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (user: UserProfile, token: string) => void;
  isDarkMode: boolean;
}

export default function AuthModal({ isOpen, onClose, onLoginSuccess, isDarkMode }: AuthModalProps) {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [errorMsg, setErrorMsg] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg("");
    setIsLoading(true);

    try {
      const endpoint = mode === "login" ? "/api/auth/login" : "/api/auth/register";
      const payload = mode === "login" ? { email, password } : { email, password, name };

      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (!res.ok || data.error) {
        throw new Error(data.error || "เกิดข้อผิดพลาดในการดำเนินการ");
      }

      onLoginSuccess(data.user, data.token);
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || "ไม่สามารถเชื่อมต่อระบบได้");
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuickDemoLogin = async () => {
    setErrorMsg("");
    setIsLoading(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: "khung.kriangkrai@gmail.com", password: "pca123456" }),
      });
      const data = await res.json();
      if (!res.ok || data.error) {
        throw new Error(data.error || "เข้าสู่ระบบ Demo ไม่สำเร็จ");
      }
      onLoginSuccess(data.user, data.token);
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || "ไม่สามารถเข้าสู่ระบบ Demo ได้");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          className={`w-full max-w-md p-6 rounded-2xl border shadow-2xl relative overflow-hidden ${
            isDarkMode ? "bg-[#18191b] border-[#2f3135] text-white" : "bg-white border-gray-200 text-gray-900"
          }`}
        >
          {/* Close button */}
          <button
            onClick={onClose}
            className={`absolute top-4 right-4 p-2 rounded-full transition-colors cursor-pointer ${
              isDarkMode ? "hover:bg-gray-800 text-gray-400" : "hover:bg-gray-100 text-gray-500"
            }`}
          >
            <X className="w-5 h-5" />
          </button>

          {/* Header */}
          <div className="space-y-2 mb-6">
            <div className="flex items-center gap-2">
              <div className="p-2.5 rounded-xl bg-orange-500/10 text-orange-500 border border-orange-500/20">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-extrabold text-lg flex items-center gap-2">
                  <span>{mode === "login" ? "เข้าสู่ระบบส่วนบุคคล" : "ลงทะเบียนบัญชีใหม่"}</span>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-orange-500/20 text-orange-400 border border-orange-500/30 font-bold uppercase">
                    PCA Auth
                  </span>
                </h3>
                <p className={`text-xs ${isDarkMode ? "text-gray-400" : "text-gray-500"}`}>
                  บันทึกประวัติการวิเคราะห์และคลังความทรงจำส่วนบุคคลโดยตรง
                </p>
              </div>
            </div>
          </div>

          {errorMsg && (
            <div className="p-3 mb-4 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs font-semibold">
              {errorMsg}
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === "register" && (
              <div className="space-y-1.5">
                <label className={`text-xs font-bold ${isDarkMode ? "text-gray-300" : "text-gray-700"}`}>
                  ชื่อ - นามสกุล หรือ ฉายา
                </label>
                <div className="relative">
                  <User className="w-4 h-4 absolute left-3 top-3 text-gray-400" />
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="เช่น กรีธา เกรียงไกร"
                    className={`w-full pl-9 pr-3 py-2.5 rounded-xl text-xs font-medium border outline-none transition-all ${
                      isDarkMode
                        ? "bg-[#212326] border-[#32353a] text-white focus:border-orange-500"
                        : "bg-gray-50 border-gray-200 text-gray-900 focus:border-orange-500"
                    }`}
                  />
                </div>
              </div>
            )}

            <div className="space-y-1.5">
              <label className={`text-xs font-bold ${isDarkMode ? "text-gray-300" : "text-gray-700"}`}>
                อีเมล (Email)
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 absolute left-3 top-3 text-gray-400" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="khung.kriangkrai@gmail.com"
                  className={`w-full pl-9 pr-3 py-2.5 rounded-xl text-xs font-medium border outline-none transition-all ${
                    isDarkMode
                      ? "bg-[#212326] border-[#32353a] text-white focus:border-orange-500"
                      : "bg-gray-50 border-gray-200 text-gray-900 focus:border-orange-500"
                  }`}
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className={`text-xs font-bold ${isDarkMode ? "text-gray-300" : "text-gray-700"}`}>
                รหัสผ่าน (Password)
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 absolute left-3 top-3 text-gray-400" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className={`w-full pl-9 pr-3 py-2.5 rounded-xl text-xs font-medium border outline-none transition-all ${
                    isDarkMode
                      ? "bg-[#212326] border-[#32353a] text-white focus:border-orange-500"
                      : "bg-gray-50 border-gray-200 text-gray-900 focus:border-orange-500"
                  }`}
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3 px-4 bg-gradient-to-r from-orange-500 to-rose-600 hover:from-orange-600 hover:to-rose-700 text-white font-extrabold text-xs rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              {mode === "login" ? <LogIn className="w-4 h-4" /> : <UserPlus className="w-4 h-4" />}
              <span>{isLoading ? "กำลังดำเนินการ..." : mode === "login" ? "เข้าสู่ระบบ" : "ยืนยันสร้างบัญชี"}</span>
            </button>
          </form>

          {/* Quick Demo Login Option */}
          <div className="mt-5 pt-4 border-t border-gray-200 dark:border-gray-800 space-y-3">
            <button
              type="button"
              onClick={handleQuickDemoLogin}
              className={`w-full py-2.5 px-3 rounded-xl border text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
                isDarkMode
                  ? "bg-[#222427] border-[#33363b] text-orange-400 hover:bg-[#282a2e]"
                  : "bg-orange-50 border-orange-200 text-orange-700 hover:bg-orange-100"
              }`}
            >
              <Sparkles className="w-4 h-4 text-orange-500" />
              <span>เข้าสู่ระบบด่วนด้วยบัญชีสถาปนิกยุทธศาสตร์ (khung.kriangkrai@gmail.com)</span>
            </button>

            <div className="text-center">
              <button
                type="button"
                onClick={() => {
                  setErrorMsg("");
                  setMode(mode === "login" ? "register" : "login");
                }}
                className={`text-xs font-bold underline cursor-pointer ${
                  isDarkMode ? "text-gray-400 hover:text-white" : "text-gray-600 hover:text-gray-900"
                }`}
              >
                {mode === "login" ? "ยังไม่มีบัญชี? กดสร้างบัญชีใหม่" : "มีบัญชีอยู่แล้ว? กดเข้าสู่ระบบ"}
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
