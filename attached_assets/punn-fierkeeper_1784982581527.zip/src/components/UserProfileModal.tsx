import React, { useState, useEffect } from "react";
import { User, Mail, Lock, ShieldCheck, Sparkles, CheckCircle2, KeyRound, UserCheck, X, Image as ImageIcon, BookOpen, AlertCircle } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export interface UserProfileData {
  id: string;
  email: string;
  name: string;
  role: string;
  avatarUrl?: string;
  personalContext?: string;
}

interface UserProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfileData | null;
  authToken: string;
  onUpdateSuccess: (updatedUser: UserProfileData) => void;
  isDarkMode: boolean;
}

const CONTEXT_PRESETS = [
  {
    title: "สถาปนิกยุทธศาสตร์องค์กร (Enterprise Architect)",
    text: "ฉันเป็นสถาปนิกยุทธศาสตร์องค์กร เน้นความมั่นคงทางเทคโนโลยี สถาปัตยกรรมระดับซอฟต์แวร์ การกำกับดูแลความเสี่ยง (Governance) และการตัดสินใจเชิงโครงสร้างระยะยาว",
  },
  {
    title: "นักลงทุน & ผู้บริหาร Tech (Tech Executive & Investor)",
    text: "ฉันเป็นผู้บริหารเทคโนโลยี เน้นความรวดเร็วในการส่งมอบสินค้า ความคุ้มค่าการลงทุน (ROI) การบริหารทรัพยากรมนุษย์ และการประเมินความเสี่ยงทางธุรกิจ",
  },
  {
    title: "นักวิจัย & การวิเคราะห์เชิงลึก (Deep Tech Researcher)",
    text: "ฉันเป็นนักวิจัยเน้นความถูกต้องเชิงตรรกะ ตรวจสอบตรรกะพิสูจน์ (Formal Verification) การประเมินจริยธรรม AI และหลักฐานเชิงประจักษ์แบบวิชาการ",
  },
  {
    title: "ผู้ประกอบการนวัตกรรม (Agile Founder)",
    text: "ฉันเป็นผู้ก่อตั้งธุรกิจนวัตกรรม เน้นการทดลองและปรับเปลี่ยนรวดเร็ว (Agile Iteration) การแก้ปัญหาหน้างาน และการคิดแบบมองข้ามกรอบเดิม",
  },
];

export default function UserProfileModal({
  isOpen,
  onClose,
  currentUser,
  authToken,
  onUpdateSuccess,
  isDarkMode,
}: UserProfileModalProps) {
  const [activeTab, setActiveTab] = useState<"profile" | "context" | "password">("profile");

  // Profile Form States
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [avatarUrl, setAvatarUrl] = useState("");
  const [personalContext, setPersonalContext] = useState("");

  // Password Form States
  const [oldPassword, setOldPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  // UI Feedback States
  const [statusMsg, setStatusMsg] = useState<{ type: "success" | "error"; text: string } | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (currentUser) {
      setName(currentUser.name || "");
      setEmail(currentUser.email || "");
      setAvatarUrl(currentUser.avatarUrl || "");
      setPersonalContext(currentUser.personalContext || "");
    }
  }, [currentUser, isOpen]);

  if (!isOpen || !currentUser) return null;

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatusMsg(null);
    setIsLoading(true);

    try {
      const res = await fetch("/api/auth/profile", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${authToken}`,
        },
        body: JSON.stringify({ name, email, avatarUrl, personalContext }),
      });

      const data = await res.json();
      if (!res.ok || data.error) {
        throw new Error(data.error || "บันทึกข้อมูลโปรไฟล์ไม่สำเร็จ");
      }

      onUpdateSuccess(data.user);
      setStatusMsg({ type: "success", text: "อัปเดตข้อมูลส่วนตัวเรียบร้อยแล้ว!" });
    } catch (err: any) {
      setStatusMsg({ type: "error", text: err.message || "เกิดข้อผิดพลาดในการบันทึก" });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveContext = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatusMsg(null);
    setIsLoading(true);

    try {
      const res = await fetch("/api/auth/profile", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${authToken}`,
        },
        body: JSON.stringify({ personalContext }),
      });

      const data = await res.json();
      if (!res.ok || data.error) {
        throw new Error(data.error || "บันทึกบริบทเฉพาะตัวไม่สำเร็จ");
      }

      onUpdateSuccess(data.user);
      setStatusMsg({ type: "success", text: "บันทึกบริบทเฉพาะตัวเรียบร้อยแล้ว! ระบบจะนำบริบทนี้ไปผสมผสานในการวิเคราะห์ยุทธศาสตร์ถัดไป" });
    } catch (err: any) {
      setStatusMsg({ type: "error", text: err.message || "เกิดข้อผิดพลาดในการบันทึก" });
    } finally {
      setIsLoading(false);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatusMsg(null);

    if (newPassword !== confirmPassword) {
      setStatusMsg({ type: "error", text: "รหัสผ่านใหม่และการยืนยันรหัสผ่านไม่ตรงกัน" });
      return;
    }

    if (newPassword.length < 6) {
      setStatusMsg({ type: "error", text: "รหัสผ่านใหม่ต้องมีความยาวอย่างน้อย 6 ตัวอักษร" });
      return;
    }

    setIsLoading(true);

    try {
      const res = await fetch("/api/auth/password", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${authToken}`,
        },
        body: JSON.stringify({ oldPassword, newPassword }),
      });

      const data = await res.json();
      if (!res.ok || data.error) {
        throw new Error(data.error || "เปลี่ยนรหัสผ่านไม่สำเร็จ");
      }

      setOldPassword("");
      setNewPassword("");
      setConfirmPassword("");
      setStatusMsg({ type: "success", text: "เปลี่ยนรหัสผ่านเรียบร้อยแล้ว!" });
    } catch (err: any) {
      setStatusMsg({ type: "error", text: err.message || "เกิดข้อผิดพลาดในการเปลี่ยนรหัสผ่าน" });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          className={`w-full max-w-2xl p-6 rounded-2xl border shadow-2xl relative overflow-hidden flex flex-col max-h-[90vh] ${
            isDarkMode ? "bg-[#18191b] border-[#2f3135] text-white" : "bg-white border-gray-200 text-gray-900"
          }`}
        >
          {/* Close button */}
          <button
            onClick={onClose}
            className={`absolute top-4 right-4 p-2 rounded-full transition-colors cursor-pointer ${
              isDarkMode ? "hover:bg-gray-800 text-gray-400" : "hover:bg-gray-100 text-gray-500"
            }`}
          >
            <X className="w-5 h-5" />
          </button>

          {/* Header */}
          <div className="flex items-center gap-3 mb-5 shrink-0">
            <div className="relative">
              {avatarUrl ? (
                <img src={avatarUrl} alt={name} className="w-12 h-12 rounded-xl object-cover ring-2 ring-orange-500/50" />
              ) : (
                <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-orange-500 to-rose-600 text-white flex items-center justify-center font-extrabold text-lg shadow-md">
                  {name ? name[0] : "U"}
                </div>
              )}
            </div>
            <div>
              <h3 className="font-extrabold text-lg flex items-center gap-2">
                <span>จัดการข้อมูลส่วนตัวและบริบทเฉพาะตัว</span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-orange-500/20 text-orange-400 font-bold border border-orange-500/30 uppercase">
                  {currentUser.role}
                </span>
              </h3>
              <p className={`text-xs ${isDarkMode ? "text-gray-400" : "text-gray-500"}`}>
                ปรับแต่งชื่อ อีเมล รูปโปรไฟล์ รหัสผ่าน และบริบทเฉพาะตัวสำหรับการประมวลผลยุทธศาสตร์
              </p>
            </div>
          </div>

          {/* Nav Tabs */}
          <div className={`flex items-center gap-1.5 p-1 rounded-xl mb-5 shrink-0 border ${
            isDarkMode ? "bg-[#222427] border-gray-800" : "bg-gray-100 border-gray-200"
          }`}>
            <button
              onClick={() => { setActiveTab("profile"); setStatusMsg(null); }}
              className={`flex-1 py-2 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
                activeTab === "profile"
                  ? isDarkMode ? "bg-[#18191b] text-orange-500 shadow-sm" : "bg-white text-orange-600 shadow-sm border border-gray-200"
                  : isDarkMode ? "text-gray-400 hover:text-white" : "text-gray-600 hover:text-gray-900"
              }`}
            >
              <User className="w-4 h-4" />
              <span>ข้อมูลโปรไฟล์</span>
            </button>

            <button
              onClick={() => { setActiveTab("context"); setStatusMsg(null); }}
              className={`flex-1 py-2 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
                activeTab === "context"
                  ? isDarkMode ? "bg-[#18191b] text-orange-500 shadow-sm" : "bg-white text-orange-600 shadow-sm border border-gray-200"
                  : isDarkMode ? "text-gray-400 hover:text-white" : "text-gray-600 hover:text-gray-900"
              }`}
            >
              <Sparkles className="w-4 h-4 text-orange-500" />
              <span>บริบทเฉพาะตัว (Personal Context)</span>
            </button>

            <button
              onClick={() => { setActiveTab("password"); setStatusMsg(null); }}
              className={`flex-1 py-2 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
                activeTab === "password"
                  ? isDarkMode ? "bg-[#18191b] text-orange-500 shadow-sm" : "bg-white text-orange-600 shadow-sm border border-gray-200"
                  : isDarkMode ? "text-gray-400 hover:text-white" : "text-gray-600 hover:text-gray-900"
              }`}
            >
              <KeyRound className="w-4 h-4" />
              <span>เปลี่ยนรหัสผ่าน</span>
            </button>
          </div>

          {statusMsg && (
            <div
              className={`p-3 mb-4 rounded-xl border text-xs font-bold flex items-center gap-2 shrink-0 ${
                statusMsg.type === "success"
                  ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-400"
                  : "bg-rose-500/10 border-rose-500/30 text-rose-400"
              }`}
            >
              {statusMsg.type === "success" ? <CheckCircle2 className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
              <span>{statusMsg.text}</span>
            </div>
          )}

          {/* Tab Contents */}
          <div className="flex-1 overflow-y-auto pr-1 space-y-4">
            {/* TAB 1: Profile Info */}
            {activeTab === "profile" && (
              <form onSubmit={handleSaveProfile} className="space-y-4">
                <div className="space-y-1.5">
                  <label className={`text-xs font-bold ${isDarkMode ? "text-gray-300" : "text-gray-700"}`}>
                    ชื่อ - นามสกุล หรือ ฉายาทางยุทธศาสตร์
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 absolute left-3 top-3 text-gray-400" />
                    <input
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className={`w-full pl-9 pr-3 py-2.5 rounded-xl text-xs font-medium border outline-none transition-all ${
                        isDarkMode
                          ? "bg-[#212326] border-[#32353a] text-white focus:border-orange-500"
                          : "bg-gray-50 border-gray-200 text-gray-900 focus:border-orange-500"
                      }`}
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className={`text-xs font-bold ${isDarkMode ? "text-gray-300" : "text-gray-700"}`}>
                    อีเมล (Email Address)
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 absolute left-3 top-3 text-gray-400" />
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className={`w-full pl-9 pr-3 py-2.5 rounded-xl text-xs font-medium border outline-none transition-all ${
                        isDarkMode
                          ? "bg-[#212326] border-[#32353a] text-white focus:border-orange-500"
                          : "bg-gray-50 border-gray-200 text-gray-900 focus:border-orange-500"
                      }`}
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className={`text-xs font-bold ${isDarkMode ? "text-gray-300" : "text-gray-700"}`}>
                    ลิงก์รูปโปรไฟล์ (Avatar Image URL)
                  </label>
                  <div className="relative">
                    <ImageIcon className="w-4 h-4 absolute left-3 top-3 text-gray-400" />
                    <input
                      type="url"
                      placeholder="https://images.unsplash.com/photo-..."
                      value={avatarUrl}
                      onChange={(e) => setAvatarUrl(e.target.value)}
                      className={`w-full pl-9 pr-3 py-2.5 rounded-xl text-xs font-medium border outline-none transition-all ${
                        isDarkMode
                          ? "bg-[#212326] border-[#32353a] text-white focus:border-orange-500"
                          : "bg-gray-50 border-gray-200 text-gray-900 focus:border-orange-500"
                      }`}
                    />
                  </div>
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    disabled={isLoading}
                    className="w-full py-3 px-4 bg-gradient-to-r from-orange-500 to-rose-600 hover:from-orange-600 hover:to-rose-700 text-white font-extrabold text-xs rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <UserCheck className="w-4 h-4" />
                    <span>{isLoading ? "กำลังบันทึก..." : "บันทึกข้อมูลส่วนตัว"}</span>
                  </button>
                </div>
              </form>
            )}

            {/* TAB 2: Personal Context */}
            {activeTab === "context" && (
              <form onSubmit={handleSaveContext} className="space-y-4">
                <div className="p-3.5 rounded-xl bg-orange-500/10 border border-orange-500/20 text-xs space-y-1">
                  <span className="font-extrabold text-orange-500 flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4" />
                    <span>ระบบบริบทเฉพาะตัว (Personal Context Engine):</span>
                  </span>
                  <p className={`leading-relaxed ${isDarkMode ? "text-gray-300" : "text-gray-800"}`}>
                    เพิ่มกรอบความคิด บทบาท ข้อจำกัดเฉพาะองค์กร หรือสไตล์การตัดสินใจของคุณ
                    ระบบสถาปัตยกรรม PCA จะนำข้อมูลนี้ไปหลอมรวมในขั้นตอน Knowledge Integration (Stage 2) โดยอัตโนมัติ
                  </p>
                </div>

                {/* Presets */}
                <div className="space-y-1.5">
                  <label className={`text-xs font-bold flex items-center gap-1 ${isDarkMode ? "text-gray-400" : "text-gray-600"}`}>
                    <BookOpen className="w-3.5 h-3.5 text-orange-500" />
                    <span>เลือกชุดบริบทแม่แบบสำเร็จรูป:</span>
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {CONTEXT_PRESETS.map((preset, idx) => (
                      <button
                        type="button"
                        key={idx}
                        onClick={() => setPersonalContext(preset.text)}
                        className={`p-2.5 rounded-xl border text-left text-xs transition-all cursor-pointer ${
                          isDarkMode
                            ? "bg-[#212326] border-[#32353a] hover:border-orange-500/50 text-gray-300"
                            : "bg-gray-50 border-gray-200 hover:border-orange-400 text-gray-800"
                        }`}
                      >
                        <div className="font-bold text-orange-500 mb-1">{preset.title}</div>
                        <p className="text-[11px] opacity-80 line-clamp-2">{preset.text}</p>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className={`text-xs font-bold ${isDarkMode ? "text-gray-300" : "text-gray-700"}`}>
                    ข้อความบริบทและหลักการเฉพาะตัวของคุณ:
                  </label>
                  <textarea
                    rows={5}
                    value={personalContext}
                    onChange={(e) => setPersonalContext(e.target.value)}
                    placeholder="เช่น: ฉันเป็น CTO บริษัทการเงิน ให้ความสำคัญกับความปลอดภัยทางcyber มาตรฐาน PDPA และภาษาที่ตรงไปตรงมา..."
                    className={`w-full p-3 rounded-xl text-xs font-medium border outline-none transition-all leading-relaxed ${
                      isDarkMode
                        ? "bg-[#212326] border-[#32353a] text-white focus:border-orange-500"
                        : "bg-gray-50 border-gray-200 text-gray-900 focus:border-orange-500"
                    }`}
                  />
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    disabled={isLoading}
                    className="w-full py-3 px-4 bg-gradient-to-r from-orange-500 to-rose-600 hover:from-orange-600 hover:to-rose-700 text-white font-extrabold text-xs rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Sparkles className="w-4 h-4" />
                    <span>{isLoading ? "กำลังบันทึก..." : "บันทึกบริบทเฉพาะตัว"}</span>
                  </button>
                </div>
              </form>
            )}

            {/* TAB 3: Change Password */}
            {activeTab === "password" && (
              <form onSubmit={handleChangePassword} className="space-y-4">
                <div className="space-y-1.5">
                  <label className={`text-xs font-bold ${isDarkMode ? "text-gray-300" : "text-gray-700"}`}>
                    รหัสผ่านเดิม (Old Password)
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 absolute left-3 top-3 text-gray-400" />
                    <input
                      type="password"
                      required
                      value={oldPassword}
                      onChange={(e) => setOldPassword(e.target.value)}
                      placeholder="••••••••"
                      className={`w-full pl-9 pr-3 py-2.5 rounded-xl text-xs font-medium border outline-none transition-all ${
                        isDarkMode
                          ? "bg-[#212326] border-[#32353a] text-white focus:border-orange-500"
                          : "bg-gray-50 border-gray-200 text-gray-900 focus:border-orange-500"
                      }`}
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className={`text-xs font-bold ${isDarkMode ? "text-gray-300" : "text-gray-700"}`}>
                    รหัสผ่านใหม่ (New Password)
                  </label>
                  <div className="relative">
                    <KeyRound className="w-4 h-4 absolute left-3 top-3 text-gray-400" />
                    <input
                      type="password"
                      required
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      placeholder="อย่างน้อย 6 ตัวอักษร"
                      className={`w-full pl-9 pr-3 py-2.5 rounded-xl text-xs font-medium border outline-none transition-all ${
                        isDarkMode
                          ? "bg-[#212326] border-[#32353a] text-white focus:border-orange-500"
                          : "bg-gray-50 border-gray-200 text-gray-900 focus:border-orange-500"
                      }`}
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className={`text-xs font-bold ${isDarkMode ? "text-gray-300" : "text-gray-700"}`}>
                    ยืนยันรหัสผ่านใหม่ (Confirm New Password)
                  </label>
                  <div className="relative">
                    <ShieldCheck className="w-4 h-4 absolute left-3 top-3 text-gray-400" />
                    <input
                      type="password"
                      required
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="กรอกรหัสผ่านใหม่อีกครั้ง"
                      className={`w-full pl-9 pr-3 py-2.5 rounded-xl text-xs font-medium border outline-none transition-all ${
                        isDarkMode
                          ? "bg-[#212326] border-[#32353a] text-white focus:border-orange-500"
                          : "bg-gray-50 border-gray-200 text-gray-900 focus:border-orange-500"
                      }`}
                    />
                  </div>
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    disabled={isLoading}
                    className="w-full py-3 px-4 bg-gradient-to-r from-orange-500 to-rose-600 hover:from-orange-600 hover:to-rose-700 text-white font-extrabold text-xs rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <KeyRound className="w-4 h-4" />
                    <span>{isLoading ? "กำลังเปลี่ยน..." : "ยืนยันเปลี่ยนรหัสผ่าน"}</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
