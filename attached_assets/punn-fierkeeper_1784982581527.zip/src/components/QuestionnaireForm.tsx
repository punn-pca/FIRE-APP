import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  FileText, 
  HelpCircle, 
  Send, 
  Sparkles, 
  CheckCircle2, 
  AlertTriangle, 
  Target, 
  X, 
  ChevronRight, 
  Flame, 
  Layers, 
  ShieldCheck,
  Plus,
  Trash2,
  Info
} from "lucide-react";

export interface InitialQuestionnaireData {
  topic: string;
  context: string;
  options: string[];
  constraints: string;
  criteria: string;
}

export interface SupplementQuestionnaireData {
  additionalContext: string;
  updatedConstraints: string;
  clarifications: string;
}

interface QuestionnaireFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmitInitial: (formattedPrompt: string, data: InitialQuestionnaireData) => void;
  onSubmitSupplement: (formattedPrompt: string, data: SupplementQuestionnaireData) => void;
  mode: "initial" | "supplement";
  isDarkMode: boolean;
  previousQuestion?: string;
  identifiedUncertainties?: string[];
  identifiedCritiques?: string[];
}

export default function QuestionnaireForm({
  isOpen,
  onClose,
  onSubmitInitial,
  onSubmitSupplement,
  mode,
  isDarkMode,
  previousQuestion = "",
  identifiedUncertainties = [],
  identifiedCritiques = []
}: QuestionnaireFormProps) {
  // Mode 1: Initial Question Form
  const [topic, setTopic] = useState("");
  const [context, setContext] = useState("");
  const [options, setOptions] = useState<string[]>(["ทางเลือกที่ 1: ", "ทางเลือกที่ 2: "]);
  const [constraints, setConstraints] = useState("");
  const [criteria, setCriteria] = useState("");

  // Mode 2: Supplement Context Form
  const [additionalContext, setAdditionalContext] = useState("");
  const [updatedConstraints, setUpdatedConstraints] = useState("");
  const [clarifications, setClarifications] = useState("");

  if (!isOpen) return null;

  // Add Option
  const handleAddOption = () => {
    setOptions(prev => [...prev, `ทางเลือกที่ ${prev.length + 1}: `]);
  };

  const handleOptionChange = (index: number, val: string) => {
    setOptions(prev => {
      const next = [...prev];
      next[index] = val;
      return next;
    });
  };

  const handleRemoveOption = (index: number) => {
    if (options.length <= 1) return;
    setOptions(prev => prev.filter((_, i) => i !== index));
  };

  // Preset Template loader for quick efficiency
  const applyTemplate = (category: string) => {
    if (category === "tech") {
      setTopic("การตัดสินใจปรับเปลี่ยนสถาปัตยกรรมระบบเทคโนโลยี");
      setContext("ระบบเดิมใช้งานมานาน โหลดช้าเมื่อผู้ใช้งานเพิ่มขึ้น ทีมวิศวกรต้องการปรับเปลี่ยนเพื่อรองรับการขยายตัว");
      setOptions([
        "ทางเลือกที่ 1: ปรับโครงสร้างใหม่ทั้งหมดไประบบ Microservices บน Cloud-Native",
        "ทางเลือกที่ 2: รักษาสถาปัตยกรรมเดิม ปรับเป็น Modular Monolith และแยกเฉพาะบริการย่อยที่มีภาระงานสูง"
      ]);
      setConstraints("งบประมาณจำกัด ห้ามกระทบผู้ใช้งานเดิม และต้องดำเนินการเสร็จภายใน 6 เดือน");
      setCriteria("ความเสถียรของระบบ (Zero Downtime), ความง่ายในการดูแลรักษาของทีม และความคุ้มค่าระยะยาว");
    } else if (category === "strategy") {
      setTopic("การกำหนดกลยุทธ์ทิศทางการเติบโตขององค์กร");
      setContext("องค์กรต้องการขยายตลาดใหม่ในสภาวะที่การแข่งขันสูงขึ้นและพฤติกรรมผู้บริโภคเปลี่ยนไป");
      setOptions([
        "ทางเลือกที่ 1: ทุ่มงบพัฒนาผลิตภัณฑ์ใหม่เชิงรุกเพื่อเจาะกลุ่มลูกค้าเจเนอเรชันใหม่",
        "ทางเลือกที่ 2: มุ่งเน้นเพิ่มประสิทธิภาพฐานผลิตภัณฑ์เดิมและสร้างพันธมิตรทางธุรกิจ"
      ]);
      setConstraints("ทรัพยากรบุคคลจำกัด และสภาวะเศรษฐกิจที่มีความผันผวน");
      setCriteria("อัตราการเติบโตของรายได้ (ROI), การรักษาฐานลูกค้าเดิม และความเสี่ยงเชิงระบบต่ำ");
    } else if (category === "investment") {
      setTopic("การประเมินความคุ้มค่าและการตัดสินใจลงทุน");
      setContext("ต้องตัดสินใจเลือกลงทุนในโครงการหรือเครื่องมือใหม่เพื่อเพิ่มศักยภาพการแข่งขัน");
      setOptions([
        "ทางเลือกที่ 1: ลงทุนซื้อและติดตั้งระบบระดับ Enterprise สัญญา 3 ปี",
        "ทางเลือกที่ 2: เริ่มต้นด้วยการทดลองใช้แบบ Pay-as-you-go ในสเกลเล็กก่อน"
      ]);
      setConstraints("ต้องคืนทุนภายใน 2 ปี และมีความเสี่ยงด้านการรักษาความปลอดภัยข้อมูลสูง");
      setCriteria("ความคุ้มค่าการลงทุน (TCO), ระยะเวลาคืนทุน และระดับความปลอดภัยของข้อมูล");
    }
  };

  const handleSubmitInitial = (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic.trim()) return;

    const filteredOptions = options.map(o => o.trim()).filter(Boolean);

    // Build formatted structured prompt for PCA Engine
    let prompt = `[การตั้งคำถามผ่านแบบสอบถามเพื่อการวิเคราะห์เชิงยุทธศาสตร์]\n`;
    prompt += `📌 หัวข้อ/ประเด็นการตัดสินใจ: ${topic.trim()}\n`;
    if (context.trim()) prompt += `📝 บริบทและสถานการณ์แวดล้อม: ${context.trim()}\n`;
    if (filteredOptions.length > 0) prompt += `🔀 ทางเลือกที่กำลังพิจารณา:\n${filteredOptions.map((opt, i) => `   ${i + 1}. ${opt}`).join("\n")}\n`;
    if (constraints.trim()) prompt += `⚠️ ข้อจำกัดและความเสี่ยงที่กังวล: ${constraints.trim()}\n`;
    if (criteria.trim()) prompt += `🎯 เกณฑ์หรือผลลัพธ์ที่คาดหวัง: ${criteria.trim()}\n`;
    prompt += `\nขอให้ระบบประมวลผลด้วยกรอบ PCA 12 ขั้นตอนอย่างแม่นยำและรัดกุมครับ`;

    onSubmitInitial(prompt, {
      topic,
      context,
      options: filteredOptions,
      constraints,
      criteria
    });
    onClose();
  };

  const handleSubmitSupplement = (e: React.FormEvent) => {
    e.preventDefault();
    if (!additionalContext.trim() && !updatedConstraints.trim() && !clarifications.trim()) return;

    let prompt = `[การเติมข้อมูลบริบทเพิ่มเติมเนื่องจากข้อมูลเดิมไม่เพียงพอในการวิเคราะห์]\n`;
    if (previousQuestion) prompt += `📌 อ้างอิงประเด็นเดิม: ${previousQuestion}\n`;
    if (additionalContext.trim()) prompt += `➕ ข้อมูลข้อเท็จจริงและบริบทเพิ่มเติม: ${additionalContext.trim()}\n`;
    if (updatedConstraints.trim()) prompt += `⚠️ ข้อจำกัดหรืองบประมาณเพิ่มเติม: ${updatedConstraints.trim()}\n`;
    if (clarifications.trim()) prompt += `🔍 การชี้แจงประเด็นความไม่แน่นอน/ข้อวิพากษ์: ${clarifications.trim()}\n`;
    prompt += `\nกรุณาประมวลผลอัปเดตการประเมินตามกรอบ PCA 12 ขั้นตอน ปรับปรุงดัชนีความมั่นใจ และจัดทำข้อสรุปยุทธศาสตร์ใหม่ครับ`;

    onSubmitSupplement(prompt, {
      additionalContext,
      updatedConstraints,
      clarifications
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/70 backdrop-blur-sm overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        transition={{ duration: 0.2 }}
        className={`w-full max-w-2xl rounded-2xl border shadow-2xl overflow-hidden my-auto ${
          isDarkMode ? "bg-[#1a1b1c] border-[#2d2f31] text-gray-100" : "bg-white border-gray-200 text-gray-900"
        }`}
      >
        {/* Header Bar */}
        <div className={`p-4 sm:p-5 border-b flex items-center justify-between ${
          isDarkMode ? "bg-[#212325] border-[#2d2f31]" : "bg-orange-50/80 border-orange-100"
        }`}>
          <div className="flex items-center gap-3">
            <div className="p-2 bg-gradient-to-tr from-amber-500 to-rose-500 rounded-xl text-white shadow-md">
              {mode === "initial" ? <FileText className="w-5 h-5" /> : <Sparkles className="w-5 h-5" />}
            </div>
            <div>
              <h3 className="font-extrabold text-sm sm:text-base flex items-center gap-2">
                <span>
                  {mode === "initial" 
                    ? "แบบสอบถามเรียบเรียงคำถามเชิงยุทธศาสตร์" 
                    : "แบบสอบถามเพิ่มข้อมูลบริบทสำหรับการวิเคราะห์"}
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded-full font-mono bg-orange-500/10 text-orange-500 border border-orange-500/20 font-bold">
                  PCA Framework
                </span>
              </h3>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">
                {mode === "initial"
                  ? "กรอกข้อมูลตามโครงสร้างเพื่อสร้างคำถามที่ถูกต้อง มีประสิทธิภาพ และทรงพลัง"
                  : "เติมข้อมูลบริบทที่ขาดหายเพื่อให้ระบบประเมินผลได้อย่างแม่นยำสูงสุด"}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className={`p-2 rounded-full transition-colors ${
              isDarkMode ? "hover:bg-[#2d2f31] text-gray-400 hover:text-white" : "hover:bg-gray-200 text-gray-500 hover:text-gray-900"
            }`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-4 sm:p-6 max-h-[80vh] overflow-y-auto space-y-5">
          {mode === "initial" ? (
            <form onSubmit={handleSubmitInitial} className="space-y-4">
              {/* Quick Template Picker */}
              <div className={`p-3 rounded-xl border space-y-2 ${
                isDarkMode ? "bg-[#131415] border-[#292b2d]" : "bg-gray-50 border-gray-200"
              }`}>
                <div className="flex items-center gap-1.5 text-xs font-bold text-orange-500">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>ตัวช่วยลัด: เลือกตัวอย่างโครงสร้างคำถามลัด</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => applyTemplate("tech")}
                    className="px-2.5 py-1 text-xs rounded-lg bg-orange-500/10 hover:bg-orange-500/20 text-orange-400 border border-orange-500/20 transition-all font-medium cursor-pointer"
                  >
                    💻 สถาปัตยกรรมระบบ/ซอฟต์แวร์
                  </button>
                  <button
                    type="button"
                    onClick={() => applyTemplate("strategy")}
                    className="px-2.5 py-1 text-xs rounded-lg bg-purple-500/10 hover:bg-purple-500/20 text-purple-400 border border-purple-500/20 transition-all font-medium cursor-pointer"
                  >
                    🎯 กลยุทธ์องค์กร/ธุรกิจ
                  </button>
                  <button
                    type="button"
                    onClick={() => applyTemplate("investment")}
                    className="px-2.5 py-1 text-xs rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/20 transition-all font-medium cursor-pointer"
                  >
                    💰 การลงทุน/งบประมาณ
                  </button>
                </div>
              </div>

              {/* Field 1: Topic */}
              <div className="space-y-1.5">
                <label className="text-xs font-extrabold flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <Target className="w-4 h-4 text-orange-500" />
                    <span>1. หัวข้อหรือเป้าหมายหลักที่ต้องการตัดสินใจ <span className="text-rose-500">*</span></span>
                  </span>
                  <span className="text-[10px] text-gray-400 font-mono">Required</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="เช่น ต้องการตัดสินใจย้ายฐานข้อมูลจาก SQL ไป NoSQL ดีไหม?"
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  className={`w-full px-3.5 py-2.5 rounded-xl border text-xs sm:text-sm transition-all focus:outline-none focus:ring-2 focus:ring-orange-500/50 ${
                    isDarkMode 
                      ? "bg-[#131415] border-[#2e3033] text-white placeholder-gray-500" 
                      : "bg-white border-gray-300 text-gray-900 placeholder-gray-400"
                  }`}
                />
              </div>

              {/* Field 2: Context */}
              <div className="space-y-1.5">
                <label className="text-xs font-extrabold flex items-center gap-1.5">
                  <Info className="w-4 h-4 text-cyan-500" />
                  <span>2. บริบทและสถานการณ์ปัจจุบัน (Context & Background)</span>
                </label>
                <textarea
                  rows={2}
                  placeholder="ระบุที่มาที่ไป ปัญหาปัจจุบัน ปริมาณงาน ทีมงาน หรือสภาพแวดล้อมที่เกี่ยวข้อง..."
                  value={context}
                  onChange={(e) => setContext(e.target.value)}
                  className={`w-full px-3.5 py-2.5 rounded-xl border text-xs sm:text-sm transition-all focus:outline-none focus:ring-2 focus:ring-orange-500/50 ${
                    isDarkMode 
                      ? "bg-[#131415] border-[#2e3033] text-white placeholder-gray-500" 
                      : "bg-white border-gray-300 text-gray-900 placeholder-gray-400"
                  }`}
                />
              </div>

              {/* Field 3: Options / Alternatives */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-extrabold flex items-center gap-1.5">
                    <Layers className="w-4 h-4 text-purple-500" />
                    <span>3. ทางเลือกที่มีอยู่ในใจ (Alternatives)</span>
                  </label>
                  <button
                    type="button"
                    onClick={handleAddOption}
                    className="text-xs font-bold text-orange-500 hover:text-orange-400 flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>เพิ่มทางเลือก</span>
                  </button>
                </div>
                <div className="space-y-2">
                  {options.map((opt, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      <input
                        type="text"
                        placeholder={`ทางเลือกที่ ${idx + 1}...`}
                        value={opt}
                        onChange={(e) => handleOptionChange(idx, e.target.value)}
                        className={`flex-1 px-3.5 py-2 rounded-xl border text-xs sm:text-sm transition-all focus:outline-none focus:ring-2 focus:ring-orange-500/50 ${
                          isDarkMode 
                            ? "bg-[#131415] border-[#2e3033] text-white placeholder-gray-500" 
                            : "bg-white border-gray-300 text-gray-900 placeholder-gray-400"
                        }`}
                      />
                      {options.length > 1 && (
                        <button
                          type="button"
                          onClick={() => handleRemoveOption(idx)}
                          className="p-2 text-rose-500 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Field 4: Constraints */}
              <div className="space-y-1.5">
                <label className="text-xs font-extrabold flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-amber-500" />
                  <span>4. ข้อจำกัดและปัจจัยเสี่ยง (Constraints & Risks)</span>
                </label>
                <input
                  type="text"
                  placeholder="เช่น งบประมาณไม่เกิน 1 ล้านบาท, ต้องเสร็จใน 3 เดือน, ห้ามกระทบกฎหมาย PDPA"
                  value={constraints}
                  onChange={(e) => setConstraints(e.target.value)}
                  className={`w-full px-3.5 py-2.5 rounded-xl border text-xs sm:text-sm transition-all focus:outline-none focus:ring-2 focus:ring-orange-500/50 ${
                    isDarkMode 
                      ? "bg-[#131415] border-[#2e3033] text-white placeholder-gray-500" 
                      : "bg-white border-gray-300 text-gray-900 placeholder-gray-400"
                  }`}
                />
              </div>

              {/* Field 5: Criteria */}
              <div className="space-y-1.5">
                <label className="text-xs font-extrabold flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-500" />
                  <span>5. เกณฑ์หรือผลลัพธ์ที่ต้องการสูงสุด (Desired Outcome / Success Criteria)</span>
                </label>
                <input
                  type="text"
                  placeholder="เช่น เน้นความเสถียรของระบบ 99.99%, เพิ่มความยืดหยุ่นให้ทีม"
                  value={criteria}
                  onChange={(e) => setCriteria(e.target.value)}
                  className={`w-full px-3.5 py-2.5 rounded-xl border text-xs sm:text-sm transition-all focus:outline-none focus:ring-2 focus:ring-orange-500/50 ${
                    isDarkMode 
                      ? "bg-[#131415] border-[#2e3033] text-white placeholder-gray-500" 
                      : "bg-white border-gray-300 text-gray-900 placeholder-gray-400"
                  }`}
                />
              </div>

              {/* Submit Button */}
              <div className="pt-3">
                <button
                  type="submit"
                  disabled={!topic.trim()}
                  className="w-full py-3 px-4 bg-gradient-to-r from-orange-500 via-amber-500 to-rose-600 hover:from-orange-600 hover:to-rose-700 disabled:opacity-50 text-white font-extrabold text-xs sm:text-sm rounded-xl shadow-lg shadow-orange-500/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                  <span>เรียบเรียงเป็นคำถามทรงประสิทธิภาพ &amp; ส่งวิเคราะห์ PCA</span>
                </button>
              </div>
            </form>
          ) : (
            <form onSubmit={handleSubmitSupplement} className="space-y-4">
              {/* Alert box showing why supplement is needed */}
              <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs space-y-1">
                <div className="flex items-center gap-1.5 font-bold text-amber-400">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>การเติมข้อมูลบริบทช่วยเพิ่มความแม่นยำในการวิเคราะห์ (Data Augmentation)</span>
                </div>
                <p className="text-gray-300 dark:text-gray-300 leading-relaxed">
                  หากผลการวิเคราะห์ก่อนหน้ามีดัชนีความมั่นใจปานกลาง หรือมีข้อวิพากษ์เรื่องข้อมูลไม่เพียงพอ คุณสามารถระบุรายละเอียดเพิ่มเติมด้านล่างเพื่ออัปเดตระบบวิเคราะห์ได้ทันที
                </p>
              </div>

              {/* Display Identified Uncertainties/Critiques if any */}
              {(identifiedUncertainties.length > 0 || identifiedCritiques.length > 0) && (
                <div className={`p-3 rounded-xl border space-y-1.5 text-xs ${
                  isDarkMode ? "bg-[#131415] border-[#2d2f31]" : "bg-rose-50/50 border-rose-100"
                }`}>
                  <span className="font-bold text-rose-400 flex items-center gap-1">
                    🔍 ประเด็นความไม่แน่นอน/ข้อวิพากษ์ที่ระบบตรวจพบ:
                  </span>
                  <ul className="list-disc pl-4 space-y-1 text-gray-400 dark:text-gray-300">
                    {identifiedUncertainties.map((u, i) => (
                      <li key={`u-${i}`}>{u}</li>
                    ))}
                    {identifiedCritiques.map((c, i) => (
                      <li key={`c-${i}`}>{c}</li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Supplement Field 1 */}
              <div className="space-y-1.5">
                <label className="text-xs font-extrabold flex items-center gap-1.5">
                  <Plus className="w-4 h-4 text-orange-500" />
                  <span>1. ข้อมูลข้อเท็จจริงหรือบริบทเพิ่มเติม (Additional Facts &amp; Context)</span>
                </label>
                <textarea
                  rows={3}
                  placeholder="ระบุตัวเลข ข้อมูลสถิติ รายละเอียดทีม หรือเงื่อนไขแวดล้อมที่ยังไม่ได้ระบุในครั้งแรก..."
                  value={additionalContext}
                  onChange={(e) => setAdditionalContext(e.target.value)}
                  className={`w-full px-3.5 py-2.5 rounded-xl border text-xs sm:text-sm transition-all focus:outline-none focus:ring-2 focus:ring-orange-500/50 ${
                    isDarkMode 
                      ? "bg-[#131415] border-[#2e3033] text-white placeholder-gray-500" 
                      : "bg-white border-gray-300 text-gray-900 placeholder-gray-400"
                  }`}
                />
              </div>

              {/* Supplement Field 2 */}
              <div className="space-y-1.5">
                <label className="text-xs font-extrabold flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-amber-500" />
                  <span>2. ข้อจำกัด เงื่อนไขงบประมาณ หรือกรอบเวลาเพิ่มเติม</span>
                </label>
                <input
                  type="text"
                  placeholder="เช่น ปรับงบประมาณเพิ่มขึ้นเป็น 1.5 ล้านบาท, กำหนดวันเสร็จแน่นอนภายในไตรมาส 3"
                  value={updatedConstraints}
                  onChange={(e) => setUpdatedConstraints(e.target.value)}
                  className={`w-full px-3.5 py-2.5 rounded-xl border text-xs sm:text-sm transition-all focus:outline-none focus:ring-2 focus:ring-orange-500/50 ${
                    isDarkMode 
                      ? "bg-[#131415] border-[#2e3033] text-white placeholder-gray-500" 
                      : "bg-white border-gray-300 text-gray-900 placeholder-gray-400"
                  }`}
                />
              </div>

              {/* Supplement Field 3 */}
              <div className="space-y-1.5">
                <label className="text-xs font-extrabold flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                  <span>3. การชี้แจงประเด็นความเสี่ยงหรือความไม่แน่นอน (Clarifications)</span>
                </label>
                <input
                  type="text"
                  placeholder="ชี้แจงหรือคลายความกังวลต่อประเด็นที่ระบบวิพากษ์ไว้ก่อนหน้า..."
                  value={clarifications}
                  onChange={(e) => setClarifications(e.target.value)}
                  className={`w-full px-3.5 py-2.5 rounded-xl border text-xs sm:text-sm transition-all focus:outline-none focus:ring-2 focus:ring-orange-500/50 ${
                    isDarkMode 
                      ? "bg-[#131415] border-[#2e3033] text-white placeholder-gray-500" 
                      : "bg-white border-gray-300 text-gray-900 placeholder-gray-400"
                  }`}
                />
              </div>

              {/* Submit Button */}
              <div className="pt-3">
                <button
                  type="submit"
                  disabled={!additionalContext.trim() && !updatedConstraints.trim() && !clarifications.trim()}
                  className="w-full py-3 px-4 bg-gradient-to-r from-orange-500 via-amber-500 to-rose-600 hover:from-orange-600 hover:to-rose-700 disabled:opacity-50 text-white font-extrabold text-xs sm:text-sm rounded-xl shadow-lg shadow-orange-500/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                  <span>ส่งข้อมูลเพิ่มเติม &amp; อัปเดตการวิเคราะห์ PCA</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </motion.div>
    </div>
  );
}
