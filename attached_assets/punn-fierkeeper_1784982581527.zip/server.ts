import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { Orchestrator } from "./src/backend/orchestrator";
import { settings, VERSION } from "./src/backend/config";
import { MemoryEngine } from "./src/backend/memory";
import { UserStore } from "./src/backend/user_store";

async function startServer() {
  const app = express();
  const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

  // Shared persistent Memory Engine to accumulate learned insights across sessions
  const sharedMemory = new MemoryEngine();
  const userStore = new UserStore();

  // Support JSON request bodies
  app.use(express.json());

  // API routes FIRST
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", version: VERSION });
  });

  // Auth routes
  app.post("/api/auth/login", (req, res) => {
    try {
      const { email, password } = req.body;
      if (!email) {
        res.status(400).json({ error: "โปรดระบุอีเมลผู้ใช้งาน" });
        return;
      }
      const result = userStore.login(email, password);
      res.json(result);
    } catch (err: any) {
      res.status(400).json({ error: err.message || "การเข้าสู่ระบบล้มเหลว" });
    }
  });

  app.post("/api/auth/register", (req, res) => {
    try {
      const { email, password, name } = req.body;
      if (!email || !password) {
        res.status(400).json({ error: "กรุณากรอกอีเมลและรหัสผ่านให้ครบถ้วน" });
        return;
      }
      const result = userStore.register(email, password, name);
      res.json(result);
    } catch (err: any) {
      res.status(400).json({ error: err.message || "การลงทะเบียนล้มเหลว" });
    }
  });

  app.get("/api/auth/me", (req, res) => {
    const authHeader = req.headers.authorization;
    const token = authHeader ? authHeader.replace("Bearer ", "") : (req.query.token as string);
    const user = userStore.getUserByToken(token);
    if (!user) {
      res.status(401).json({ error: "Unauthorized" });
      return;
    }
    res.json({ user, token });
  });

  app.post("/api/auth/profile", (req, res) => {
    try {
      const authHeader = req.headers.authorization;
      const token = authHeader ? authHeader.replace("Bearer ", "") : (req.body.token as string);
      const user = userStore.getUserByToken(token);
      if (!user) {
        res.status(401).json({ error: "กรุณาเข้าสู่ระบบก่อนทำรายการ" });
        return;
      }
      const { name, email, avatarUrl, personalContext } = req.body;
      const updatedUser = userStore.updateProfile(user.id, { name, email, avatarUrl, personalContext });
      res.json({ success: true, user: updatedUser });
    } catch (err: any) {
      res.status(400).json({ error: err.message || "อัปเดตข้อมูลโปรไฟล์ไม่สำเร็จ" });
    }
  });

  app.post("/api/auth/password", (req, res) => {
    try {
      const authHeader = req.headers.authorization;
      const token = authHeader ? authHeader.replace("Bearer ", "") : (req.body.token as string);
      const user = userStore.getUserByToken(token);
      if (!user) {
        res.status(401).json({ error: "กรุณาเข้าสู่ระบบก่อนทำรายการ" });
        return;
      }
      const { oldPassword, newPassword } = req.body;
      userStore.changePassword(user.id, oldPassword, newPassword);
      res.json({ success: true, message: "เปลี่ยนรหัสผ่านเรียบร้อยแล้ว" });
    } catch (err: any) {
      res.status(400).json({ error: err.message || "เปลี่ยนรหัสผ่านไม่สำเร็จ" });
    }
  });

  // User Personal History routes
  app.get("/api/user/history", (req, res) => {
    const authHeader = req.headers.authorization;
    const token = authHeader ? authHeader.replace("Bearer ", "") : (req.query.token as string);
    const user = userStore.getUserByToken(token);
    const userId = user ? user.id : "guest";
    const history = userStore.getHistoryByUser(userId);
    res.json({ history });
  });

  app.post("/api/user/history", (req, res) => {
    const authHeader = req.headers.authorization;
    const token = authHeader ? authHeader.replace("Bearer ", "") : (req.body.token as string);
    const user = userStore.getUserByToken(token);
    const userId = user ? user.id : "guest";

    const { question, response, understanding, purpose, decision, confidence, critique, notes, llm_provider, llm_model, execution_time_ms, questionnaireData } = req.body;

    if (!question) {
      res.status(400).json({ error: "Question is required." });
      return;
    }

    const saved = userStore.saveHistory(userId, {
      question,
      response,
      understanding,
      purpose,
      decision,
      confidence,
      critique,
      notes,
      llm_provider,
      llm_model,
      execution_time_ms,
      questionnaireData,
    });

    res.json({ success: true, historyItem: saved });
  });

  app.delete("/api/user/history", (req, res) => {
    const authHeader = req.headers.authorization;
    const token = authHeader ? authHeader.replace("Bearer ", "") : (req.query.token as string || req.body?.token);
    const user = userStore.getUserByToken(token);
    const userId = user ? user.id : "guest";
    const historyId = req.body?.historyId || req.query?.historyId;

    if (historyId) {
      userStore.deleteHistoryEntry(userId, historyId as string);
    } else {
      userStore.clearHistory(userId);
    }

    res.json({ success: true, history: userStore.getHistoryByUser(userId) });
  });

  app.post("/api/analyze", async (req, res) => {
    const { question, llm_provider, llm_model, tone, deepReasoning, personalContext: clientContext } = req.body || {};

    if (!question || !question.trim()) {
      res.status(400).json({ error: "Question cannot be empty." });
      return;
    }

    // Retrieve user for personalContext
    const authHeader = req.headers.authorization;
    const token = authHeader ? authHeader.replace("Bearer ", "") : (req.body.token as string);
    const user = userStore.getUserByToken(token);
    const activeContext = clientContext || (user ? user.personalContext : "");

    try {
      // Initialize an orchestrator with the shared persistent memory
      const orchestrator = new Orchestrator({
        memory: sharedMemory,
        provider: llm_provider || settings.llm.provider,
        model: llm_model || settings.llm.model,
        temperature: settings.llm.temperature,
        tone: tone || "Formal Architect",
        deepReasoning: !!deepReasoning,
        personalContext: activeContext,
      });

      const startTime = Date.now();
      const state = await orchestrator.think(question);
      const executionTimeMs = Date.now() - startTime;

      res.json({
        question: state.user_input,
        response: state.response,
        trace: state.trace,
        notes: state.notes,
        observations: state.observations,
        understanding: state.understanding,
        purpose: state.purpose,
        decision: state.decision,
        confidence: state.confidence,
        critique: state.critique,
        reflection: state.reflection,
        learning: state.learning,
        agency_checks: state.agency_checks,
        reasoning_graph: state.reasoning_graph,
        strategy_selection: state.strategy_selection,
        memory_traces: state.memory_traces,
        llm_provider: orchestrator.provider || "google",
        llm_model: orchestrator.model || "gemini-2.5-flash",
        execution_time_ms: executionTimeMs,
        start_time: new Date(startTime).toISOString(),
        end_time: new Date().toISOString(),
      });
    } catch (error: any) {
      console.error("Analysis failed:", error);
      res.status(500).json({ error: error?.message || "An internal error occurred." });
    }
  });

  // Memory management endpoints
  app.get("/api/memory", (req, res) => {
    res.json(sharedMemory.getAllItems());
  });

  app.post("/api/memory", (req, res) => {
    const { content, layer, source } = req.body;
    if (!content) {
      res.status(400).json({ error: "Content is required." });
      return;
    }
    sharedMemory.remember({
      content,
      layer: layer || "project",
      source: source || "user_manual",
      confidence: 1.0,
      created_at: new Date().toISOString(),
    });
    res.json({ success: true, items: sharedMemory.getAllItems() });
  });

  app.delete("/api/memory", (req, res) => {
    const { content } = req.body;
    if (!content) {
      res.status(400).json({ error: "Content is required to delete memory." });
      return;
    }
    const success = sharedMemory.deleteItem(content);
    res.json({ success, items: sharedMemory.getAllItems() });
  });

  app.post("/api/memory/clear", (req, res) => {
    sharedMemory.clearMemory();
    res.json({ success: true, items: [] });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
    console.log("Vite development server middleware loaded.");
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
    console.log("Production static files serving loaded.");
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start server:", err);
  process.exit(1);
});
