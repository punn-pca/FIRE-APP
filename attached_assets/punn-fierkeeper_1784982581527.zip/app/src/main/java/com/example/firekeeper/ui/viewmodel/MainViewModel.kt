package com.example.firekeeper.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.firekeeper.model.*
import com.example.firekeeper.repository.CognitiveRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class MainViewModel(
    private val repository: CognitiveRepository = CognitiveRepository()
) : ViewModel() {

    private val _userProfile = MutableStateFlow(UserProfile())
    val userProfile: StateFlow<UserProfile> = _userProfile.asStateFlow()

    private val _memories = MutableStateFlow<List<MemoryItem>>(emptyList())
    val memories: StateFlow<List<MemoryItem>> = _memories.asStateFlow()

    private val _chatSessions = MutableStateFlow<List<ChatSession>>(emptyList())
    val chatSessions: StateFlow<List<ChatSession>> = _chatSessions.asStateFlow()

    private val _currentSessionId = MutableStateFlow<String>("")
    val currentSessionId: StateFlow<String> = _currentSessionId.asStateFlow()

    private val _isThinking = MutableStateFlow(false)
    val isThinking: StateFlow<Boolean> = _isThinking.asStateFlow()

    private val _isDarkMode = MutableStateFlow(true)
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    private val _showMemoryPanel = MutableStateFlow(false)
    val showMemoryPanel: StateFlow<Boolean> = _showMemoryPanel.asStateFlow()

    private val _showQuestionnaire = MutableStateFlow(false)
    val showQuestionnaire: StateFlow<Boolean> = _showQuestionnaire.asStateFlow()

    private val _showProfileModal = MutableStateFlow(false)
    val showProfileModal: StateFlow<Boolean> = _showProfileModal.asStateFlow()

    init {
        loadMemories()
        createNewSession("เริ่มต้นการวิเคราะห์")
    }

    private fun loadMemories() {
        viewModelScope.launch {
            _memories.value = repository.getMemories()
        }
    }

    fun toggleDarkMode() {
        _isDarkMode.value = !_isDarkMode.value
    }

    fun setShowMemoryPanel(show: Boolean) {
        _showMemoryPanel.value = show
    }

    fun setShowQuestionnaire(show: Boolean) {
        _showQuestionnaire.value = show
    }

    fun setShowProfileModal(show: Boolean) {
        _showProfileModal.value = show
    }

    fun updateUserProfile(profile: UserProfile) {
        _userProfile.value = profile
    }

    fun createNewSession(title: String = "การวิเคราะห์ยุทธศาสตร์ใหม่") {
        val newId = UUID.randomUUID().toString()
        val welcomeMessage = Message(
            id = UUID.randomUUID().toString(),
            role = "assistant",
            content = "สวัสดีครับ ผมคือ FIRE KEEPER ระบบประมวลผลปัญญาประดิษฐ์ตามกรอบ PUNN Cognitive Architecture (PCA)\n\nพร้อมช่วยเหลือคุณในการวิเคราะห์และประเมินทางเลือกเชิงยุทธศาสตร์อย่างโปร่งใส โดยรักษาเสรีภาพในการเลือกของคุณ (Human Agency)",
            timestamp = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        )
        val session = ChatSession(
            id = newId,
            title = title,
            messages = listOf(welcomeMessage)
        )
        _chatSessions.value = listOf(session) + _chatSessions.value
        _currentSessionId.value = newId
    }

    fun selectSession(sessionId: String) {
        _currentSessionId.value = sessionId
    }

    fun deleteSession(sessionId: String) {
        _chatSessions.value = _chatSessions.value.filter { it.id != sessionId }
        if (_currentSessionId.value == sessionId) {
            val remaining = _chatSessions.value
            if (remaining.isNotEmpty()) {
                _currentSessionId.value = remaining.first().id
            } else {
                createNewSession()
            }
        }
    }

    fun sendMessage(input: String) {
        if (input.isBlank() || _isThinking.value) return

        val timeStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        val userMsg = Message(
            id = UUID.randomUUID().toString(),
            role = "user",
            content = input,
            timestamp = timeStr
        )

        val activeSessionId = _currentSessionId.value
        _chatSessions.value = _chatSessions.value.map { session ->
            if (session.id == activeSessionId) {
                session.copy(messages = session.messages + userMsg)
            } else session
        }

        _isThinking.value = true

        viewModelScope.launch {
            try {
                val pcaState = repository.executeCognitivePipeline(
                    userInput = input,
                    profile = _userProfile.value
                )

                val assistantMsg = Message(
                    id = UUID.randomUUID().toString(),
                    role = "assistant",
                    content = pcaState.responseText,
                    timestamp = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()),
                    pcaState = pcaState
                )

                _chatSessions.value = _chatSessions.value.map { session ->
                    if (session.id == activeSessionId) {
                        session.copy(messages = session.messages + assistantMsg)
                    } else session
                }
                loadMemories()
            } finally {
                _isThinking.value = false
            }
        }
    }

    fun submitQuestionnaire(data: QuestionnaireData) {
        setShowQuestionnaire(false)
        val promptText = "หัวข้อ/ประเด็นการตัดสินใจ: ${data.domain}\nบริบทและสถานการณ์แวดล้อม: ${data.context}\nปัจจัยที่ต้องนำมาพิจารณา: ${data.decisionFactors}\nข้อจำกัด/ความเสี่ยง: ${data.constraints}"
        sendMessage(promptText)
    }

    fun addMemory(content: String, layer: MemoryLayer) {
        viewModelScope.launch {
            repository.addMemory(content, layer, "User Input")
            loadMemories()
        }
    }

    fun deleteMemory(id: String) {
        viewModelScope.launch {
            repository.deleteMemory(id)
            loadMemories()
        }
    }

    fun clearMemories() {
        viewModelScope.launch {
            repository.clearMemories()
            loadMemories()
        }
    }
}
