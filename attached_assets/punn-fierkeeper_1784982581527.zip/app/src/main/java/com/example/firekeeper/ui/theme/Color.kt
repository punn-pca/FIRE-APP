package com.example.firekeeper.ui.theme

import androidx.compose.ui.graphics.Color

val FireOrange = Color(0xFFF97316)
val FireAmber = Color(0xFFF59E0B)
val FireRed = Color(0xFFEF4444)

val DarkBackground = Color(0xFF131314)
val DarkSurface = Color(0xFF1E1F20)
val DarkSurfaceVariant = Color(0xFF2A2B2D)
val DarkCardBorder = Color(0xFF3C4043)

val LightBackground = Color(0xFFFAFAFA)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF0F3F6)
val LightCardBorder = Color(0xFFE1E7EE)

val TextPrimaryDark = Color(0xFFE3E3E3)
val TextSecondaryDark = Color(0xFF9AA0A6)

val TextPrimaryLight = Color(0xFF1F2937)
val TextSecondaryLight = Color(0xFF4B5563)

val CyanAccent = Color(0xFF06B6D4)
val PurpleAccent = Color(0xFFA855F7)
val EmeraldAccent = Color(0xFF10B981)
val RoseAccent = Color(0xFFF43F5E)
