package com.example.firekeeper.ui.dialogs

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

data class QuestionnaireFormState(
    val domain: String = "",
    val context: String = "",
    val decisionFactors: String = "",
    val constraints: String = ""
)

@Composable
fun QuestionnaireDialog(
    onDismiss: () -> Unit,
    onSubmit: (QuestionnaireFormState) -> Unit
) {
    var domain by remember { mutableStateOf("") }
    var context by remember { mutableStateOf("") }
    var decisionFactors by remember { mutableStateOf("") }
    var constraints by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "แบบสอบถามบริบทการตัดสินใจ (PCA)",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "ระบุข้อมูลเพื่อเปิดใช้งาน Full-Scale Deep Analysis Report",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                OutlinedTextField(
                    value = domain,
                    onValueChange = { domain = it },
                    label = { Text("1. หัวข้อ / ประเด็นการตัดสินใจ") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("questionnaire_domain_input"),
                    singleLine = true
                )

                OutlinedTextField(
                    value = context,
                    onValueChange = { context = it },
                    label = { Text("2. บริบทและสถานการณ์แวดล้อม") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("questionnaire_context_input"),
                    minLines = 2
                )

                OutlinedTextField(
                    value = decisionFactors,
                    onValueChange = { decisionFactors = it },
                    label = { Text("3. ปัจจัยสำคัญที่ต้องนำมาประเมิน") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("questionnaire_factors_input"),
                    minLines = 2
                )

                OutlinedTextField(
                    value = constraints,
                    onValueChange = { constraints = it },
                    label = { Text("4. ข้อจำกัด หรือ ความเสี่ยงที่กังวล") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("questionnaire_constraints_input"),
                    minLines = 2
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (domain.isNotBlank()) {
                        onSubmit(
                            QuestionnaireFormState(
                                domain = domain,
                                context = context,
                                decisionFactors = decisionFactors,
                                constraints = constraints
                            )
                        )
                    }
                },
                modifier = Modifier.testTag("submit_questionnaire_button")
            ) {
                Text("เริ่มการวิเคราะห์เจาะลึก")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("cancel_questionnaire_button")
            ) {
                Text("ยกเลิก")
            }
        }
    )
}
