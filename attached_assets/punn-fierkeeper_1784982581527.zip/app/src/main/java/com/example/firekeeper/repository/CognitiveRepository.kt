package com.example.firekeeper.repository

import com.example.firekeeper.model.*
import kotlinx.coroutines.dispatchers.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*
import javax.net.ssl.HttpsURLConnection

class CognitiveRepository {

    private val memoryStore = mutableListOf<MemoryItem>()
    private var baseUrl: String = "https://ais-dev-kqoc24uupzyltkbc4vfdqc-553439259113.asia-southeast1.run.app/api"

    fun setBaseUrl(url: String) {
        if (url.isNotBlank()) {
            this.baseUrl = url.trimEnd('/')
        }
    }

    init {
        // Initialize with default project memories
        memoryStore.add(
            MemoryItem(
                id = "Memory #1",
                content = "หลักการ Human Agency Preservation: AI ต้องสนับสนุนเสรีภาพในการตัดสินใจของมนุษย์ ไม่ตัดสินใจแทนมนุษย์",
                layer = MemoryLayer.PROJECT,
                source = "PCA Constitutional Specification",
                confidence = 0.95
            )
        )
        memoryStore.add(
            MemoryItem(
                id = "Memory #2",
                content = "หลักการ Evidence Before Confidence: ระดับความเชื่อมั่นต้องแปรผันตรงตามน้ำหนักหลักฐานประจักษ์",
                layer = MemoryLayer.PROJECT,
                source = "PCA Constitutional Specification",
                confidence = 0.92
            )
        )
        memoryStore.add(
            MemoryItem(
                id = "Memory #3",
                content = "หลักการ Scoped Conclusion: แยกแยะ Fact ออกจาก Interpretation และระบุขอบเขตเงื่อนไขเสมอ",
                layer = MemoryLayer.PROJECT,
                source = "PCA Constitutional Specification",
                confidence = 0.90
            )
        )
    }

    suspend fun getMemories(): List<MemoryItem> = withContext(Dispatchers.IO) {
        return@withContext memoryStore.toList()
    }

    suspend fun addMemory(content: String, layer: MemoryLayer, source: String): MemoryItem = withContext(Dispatchers.IO) {
        val newItem = MemoryItem(
            id = "Memory #${memoryStore.size + 1}",
            content = content,
            layer = layer,
            source = source,
            confidence = 0.80
        )
        memoryStore.add(newItem)
        return@withContext newItem
    }

    suspend fun deleteMemory(id: String): Boolean = withContext(Dispatchers.IO) {
        return@withContext memoryStore.removeIf { it.id == id }
    }

    suspend fun clearMemories() = withContext(Dispatchers.IO) {
        memoryStore.clear()
    }

    suspend fun executeCognitivePipeline(
        userInput: String,
        profile: UserProfile,
        questionnaire: QuestionnaireData? = null
    ): CognitiveState = withContext(Dispatchers.IO) {
        val obs = if (questionnaire != null && questionnaire.domain.isNotBlank()) {
            "โจทย์: ${questionnaire.domain} | บริบท: ${questionnaire.context}"
        } else {
            userInput.trim()
        }

        // Try calling remote HTTPS backend API first
        val remoteResult = fetchRemoteAnalysis(obs, profile)
        if (remoteResult != null) {
            return@withContext remoteResult
        }

        // Fallback to local PCA pipeline execution
        return@withContext executeLocalCognitivePipeline(obs, profile)
    }

    private fun fetchRemoteAnalysis(question: String, profile: UserProfile): CognitiveState? {
        try {
            val url = URL("$baseUrl/analyze")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                setRequestProperty("Accept", "application/json")
                connectTimeout = 10000
                readTimeout = 25000
                doOutput = true
            }

            val jsonBody = JSONObject().apply {
                put("question", question)
                put("llm_provider", "openai")
                put("llm_model", "gpt-4o-mini")
                put("tone", "Empathetic Guide")
                put("deepReasoning", true)
            }

            OutputStreamWriter(conn.outputStream, "UTF-8").use { writer ->
                writer.write(jsonBody.toString())
                writer.flush()
            }

            val statusCode = conn.responseCode
            if (statusCode == HttpURLConnection.HTTP_OK) {
                val responseStr = BufferedReader(InputStreamReader(conn.inputStream, "UTF-8")).use { it.readText() }
                val jsonResp = JSONObject(responseStr)
                val answer = jsonResp.optString("answer", "")
                
                if (answer.isNotBlank()) {
                    return executeLocalCognitivePipeline(question, profile, overrideAnswer = answer)
                }
            }
        } catch (e: Exception) {
            // Log or handle network error silently and proceed with fallback
            e.printStackTrace()
        }
        return null
    }

    private fun executeLocalCognitivePipeline(
        obs: String,
        profile: UserProfile,
        overrideAnswer: String? = null
    ): CognitiveState {
        val dateStr = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())

        // Stage 2: Understanding
        val understandingText = if (obs.contains("ตัดสินใจ") || obs.contains("เลือก")) {
            "ผู้ใช้กำลังประเมินเปรียบเทียบทางเลือกยุทธศาสตร์เพื่อตัดสินใจ ภายใต้ข้อจำกัดและผลกระทบข้างเคียง"
        } else if (obs.contains("จริยธรรม") || obs.contains("ความจริง") || obs.contains("ปรัชญา")) {
            "ผู้ใช้ต้องการสำรวจมิติทางจริยธรรมและปรัชญา เพื่อสร้างความชัดเจนเชิงกรอบความคิด"
        } else {
            "ผู้ใช้ต้องการการวิเคราะห์เชิงยุทธศาสตร์ที่แยกแยะข้อเท็จจริงออกจากข้อสันนิษฐาน"
        }

        // Stage 3: Purpose
        val purposeText = "สถาปนากรอบความคิดเชิงเหตุผล และนำเสนอทางเลือกขนานที่โปร่งใสโดยรักษา Human Agency"

        // Stage 4: Memory
        val retrieved = memoryStore.take(3)
        val traces = retrieved.map { mem ->
            MemoryTrace(
                memoryId = mem.id,
                createdByStage = mem.createdByStage,
                usedInConversations = listOf("Session #${(100..999).random()}"),
                confidenceFrom = mem.confidence,
                confidenceTo = (mem.confidence + 0.05).coerceAtMost(0.98),
                content = mem.content,
                layer = mem.layer.label
            )
        }

        // Stage 5: Mental Model & Strategy Selection
        val mentalModelText = "Adversarial Dialectic Matrix (Pros/Cons & Counter-Evidence)"
        val strategySelection = StrategySelection(
            chosenStrategy = "Adversarial Dialectic Matrix",
            rationale = "ประเมินทางเลือกขนานร่วมกับหลักฐานโต้แย้ง เพื่อป้องกัน confirmation bias",
            consideredStrategies = listOf(
                StrategyOption(
                    name = "Adversarial Dialectic Matrix",
                    status = "selected",
                    pros = "แยกแยะ Fact vs Interpretation และระบุ failure conditions",
                    cons = "ต้องประมวลผลกระบวนการวิพากษ์ multi-stage critique"
                ),
                StrategyOption(
                    name = "Bayesian Inference Network",
                    status = "rejected",
                    pros = "คำนวณการอัปเดตความน่าจะเป็นเชิงตัวเลข",
                    cons = "ขาดข้อมูลความน่าจะเป็นเริ่มต้น (Prior Probability) ที่วัดได้อย่างอิสระ",
                    rejectionReason = "คำขอนี้ไม่มีชุดข้อมูลตัวเลขปริมาณประจักษ์"
                )
            )
        )

        // Stage 6: Hypotheses
        val hypotheses = listOf(
            "สมมติฐานที่ 1: การเริ่มทดลองในขอบเขตเล็ก (Minimal Viable Experiment) ช่วยลดความเสี่ยงสูงสุด",
            "สมมติฐานที่ 2: การลงทุนในโครงสร้างพื้นฐานระยะยาวคุ้มค่ากว่าแม้เพิ่มความซับซ้อนในระยะแรก"
        )

        // Stage 7: Evidence Evaluation
        val evalText = "การประเมินหลักฐานพบว่าสมมติฐานที่ 1 มีน้ำหนักความคุ้มค่าและความเสี่ยงต่ำในระยะสั้น ขณะที่สมมติฐานที่ 2 ต้องยืนยันความพร้อมของระบบสำรองก่อน"
        val confidenceVal = if (retrieved.isNotEmpty()) 0.82 else 0.65

        // Stage 8: Critique
        val critiqueList = listOf(
            "การวิเคราะห์อาจยังมีอคติการยืนยัน (Confirmation Bias) จากข้อมูลตั้งต้น",
            "ทางเลือกที่มีต้นทุนต่ำสุดอาจมีความเสี่ยงซ่อนเร้นในระยะยาวที่ต้องเฝ้าระวัง"
        )

        // Stage 9: Decision & Graph
        val decisionText = "ข้อสรุปเชิงยุทธศาสตร์: จากข้อมูลเบื้องต้น มีแนวโน้มว่าควรเริ่มทดสอบในขอบเขตเล็กก่อนเพื่อประเมินความคุ้มค่า (ระดับความมั่นใจ: ปานกลาง)"
        val reasoningGraph = ReasoningGraph(
            nodes = listOf(
                GraphNode("p1", NodeType.PROBLEM, "Core Request", obs, 1.0),
                GraphNode("a1", NodeType.ASSUMPTION, "Assumption 1", hypotheses[0], 0.8),
                GraphNode("e1", NodeType.EVIDENCE, "Supporting Evidence", evalText, 0.82),
                GraphNode("e2", NodeType.COUNTER_EVIDENCE, "Counter-Evidence", critiqueList[0], 0.78),
                GraphNode("c1", NodeType.CONSTRAINT, "Boundary Conditions", "ต้องไม่กระทบต่อความปลอดภัยและเสรีภาพของมนุษย์", 0.90),
                GraphNode("d1", NodeType.DECISION, "Strategic Conclusion", decisionText, 0.82)
            ),
            edges = listOf(
                GraphEdge("p1", "a1", "formulates", "derives_from"),
                GraphEdge("a1", "e1", "evaluates", "supports"),
                GraphEdge("a1", "e2", "critiques", "refutes"),
                GraphEdge("e1", "c1", "bounded by", "constrains"),
                GraphEdge("c1", "d1", "derives", "derives_from")
            )
        )

        // Stage 10: Communication Response Formatting
        val responseText = if (!overrideAnswer.isNullOrBlank()) {
            overrideAnswer
        } else {
            val responseBuilder = StringBuilder()
            responseBuilder.append("จากการประเมินเบื้องต้นตามกรอบ PUNN Cognitive Architecture (PCA):\n\n")
            responseBuilder.append("### 1. บริบทและการทำความเข้าใจ (Understanding)\n")
            responseBuilder.append("$understandingText\n\n")
            responseBuilder.append("### 2. ข้อสรุปเชิงยุทธศาสตร์และแนวทางที่แนะนำ (Strategic Recommendation)\n")
            responseBuilder.append("- **การประเมินทางเลือก**: จากข้อมูลที่มีในปัจจุบัน การเริ่มทดสอบในสเกลเล็กเพื่อรวบรวมหลักฐานประจักษ์ อาจเป็นแนวทางที่เหมาะสมกว่าในการจำกัดความเสี่ยงเชิงโครงสร้าง\n")
            responseBuilder.append("- **การประเมินความเสี่ยง**: ${critiqueList[0]}\n\n")
            responseBuilder.append("### 3. การอ้างอิงมาตรฐานและการเปิดเผยข้อจำกัด (Boundaries & Standards)\n")
            responseBuilder.append("- **มาตรฐานอ้างอิง**: สอดคล้องกับกรอบบริหารจัดการความเสี่ยง NIST AI RMF (NIST AI 100-1) ด้าน Governance และ Transparency\n")
            responseBuilder.append("- **ข้อจำกัดของแนวทาง**: แนวทางนี้ยังไม่สามารถพิสูจน์ได้ว่าจะป้องกันความเสี่ยงในทุกสถานการณ์ โดยเฉพาะเมื่อบริบทแวดล้อมเปลี่ยนแปลงกะทันหัน\n\n")
            responseBuilder.append("[DECISION_SUMMARY]: จากหลักฐานปัจจุบันมีแนวโน้มปานกลางว่าควรเริ่มทดสอบในขอบเขตเล็กก่อนเพื่อประเมินความคุ้มค่า")
            responseBuilder.toString()
        }

        // Stage 11: Reflection
        val reflectionList = listOf(
            "การให้ทางเลือกขนานช่วยรักษา Human Agency ของผู้ใช้งาน",
            "ควรติดตามผลลัพธ์จากการทดลองสเกลเล็กเพื่ออัปเดตค่าความเชื่อมั่นต่อไป"
        )

        // Stage 12: Learning
        val learningNotes = listOf(
            "บันทึกความจำใหม่เกี่ยวกับบริบทการตัดสินใจนี้เข้าสู่คลังความทรงจำระดับ Project Memory"
        )

        // Build 12 trace entries
        val traceEntries = CognitiveStage.entries.map { stage ->
            CognitiveTraceEntry(
                stage = stage,
                timestamp = dateStr,
                summary = "ประมวลผลขั้นตอน ${stage.stageNameTH}"
            )
        }

        return CognitiveState(
            userInput = obs,
            observations = listOf(obs),
            understanding = understandingText,
            purpose = purposeText,
            memories = retrieved,
            mentalModel = mentalModelText,
            hypotheses = hypotheses,
            evaluation = evalText,
            confidence = confidenceVal,
            critique = critiqueList,
            decision = decisionText,
            responseText = responseText,
            reflection = reflectionList,
            learningNotes = learningNotes,
            traces = traceEntries,
            reasoningGraph = reasoningGraph,
            strategySelection = strategySelection,
            memoryTraces = traces
        )
    }
}
