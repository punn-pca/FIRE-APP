package com.example.firekeeper.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.border
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.firekeeper.model.Message
import com.example.firekeeper.ui.components.CognitiveOrchestrationCard
import com.example.firekeeper.ui.dialogs.*
import com.example.firekeeper.ui.theme.FireAmber
import com.example.firekeeper.ui.theme.FireOrange
import com.example.firekeeper.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val isDarkMode by viewModel.isDarkMode.collectAsState()
    val isThinking by viewModel.isThinking.collectAsState()
    val chatSessions by viewModel.chatSessions.collectAsState()
    val currentSessionId by viewModel.currentSessionId.collectAsState()
    val userProfile by viewModel.userProfile.collectAsState()
    val memories by viewModel.memories.collectAsState()

    val showMemoryPanel by viewModel.showMemoryPanel.collectAsState()
    val showQuestionnaire by viewModel.showQuestionnaire.collectAsState()
    val showProfileModal by viewModel.showProfileModal.collectAsState()

    var textInput by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    val currentSession = chatSessions.find { it.id == currentSessionId }
    val messages = currentSession?.messages ?: emptyList()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(FireOrange),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.LocalFireDepartment,
                                contentDescription = "Firekeeper Icon",
                                tint = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "FIRE KEEPER",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "PCA Cognitive System (${userProfile.tone})",
                                style = MaterialTheme.typography.bodySmall,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.setShowQuestionnaire(true) },
                        modifier = Modifier.testTag("open_questionnaire_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Assignment,
                            contentDescription = "Questionnaire Form",
                            tint = FireAmber
                        )
                    }
                    IconButton(
                        onClick = { viewModel.setShowMemoryPanel(true) },
                        modifier = Modifier.testTag("open_memory_panel_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Memory,
                            contentDescription = "Memory Store",
                            tint = FireOrange
                        )
                    }
                    IconButton(
                        onClick = { viewModel.setShowProfileModal(true) },
                        modifier = Modifier.testTag("open_profile_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = "User Profile"
                        )
                    }
                    IconButton(
                        onClick = { viewModel.toggleDarkMode() },
                        modifier = Modifier.testTag("toggle_dark_mode_button")
                    ) {
                        Icon(
                            imageVector = if (isDarkMode) Icons.Default.LightMode else Icons.Default.DarkMode,
                            contentDescription = "Toggle Theme"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            val infiniteTransition = rememberInfiniteTransition(label = "flicker")
            val flickerAlpha by infiniteTransition.animateFloat(
                initialValue = 0.3f,
                targetValue = 0.95f,
                animationSpec = infiniteRepeatable(
                    animation = tween(900, easing = LinearEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "flickerAlpha"
            )

            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = textInput,
                        onValueChange = { textInput = it },
                        placeholder = { Text("ถาม หรือ ระบุโจทย์วิเคราะห์...") },
                        modifier = Modifier
                            .weight(1f)
                            .then(
                                if (isThinking) {
                                    Modifier.border(
                                        width = 2.dp,
                                        color = FireOrange.copy(alpha = flickerAlpha),
                                        shape = RoundedCornerShape(24.dp)
                                    )
                                } else Modifier
                            )
                            .testTag("chat_input_field"),
                        shape = RoundedCornerShape(24.dp),
                        singleLine = false,
                        maxLines = 4,
                        trailingIcon = {
                            IconButton(
                                onClick = {
                                    if (textInput.isNotBlank()) {
                                        viewModel.sendMessage(textInput)
                                        textInput = ""
                                    }
                                },
                                enabled = textInput.isNotBlank() && !isThinking,
                                modifier = Modifier.testTag("send_message_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Send,
                                    contentDescription = "Send Message",
                                    tint = if (textInput.isNotBlank()) FireOrange else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    )
                }
            }
        },
        modifier = modifier
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(vertical = 12.dp)
            ) {
                items(messages) { msg ->
                    ChatMessageItem(message = msg)
                }

                if (isThinking) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant
                            ),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .padding(vertical = 8.dp)
                                .testTag("thinking_indicator")
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    color = FireOrange,
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "กำลังประมวลผลผ่าน 12 ขั้นตอน PUNN Cognitive Pipeline...",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Dialog Modals
    if (showQuestionnaire) {
        QuestionnaireDialog(
            onDismiss = { viewModel.setShowQuestionnaire(false) },
            onSubmit = { data ->
                viewModel.submitQuestionnaire(
                    com.example.firekeeper.model.QuestionnaireData(
                        domain = data.domain,
                        context = data.context,
                        decisionFactors = data.decisionFactors,
                        constraints = data.constraints
                    )
                )
            }
        )
    }

    if (showProfileModal) {
        UserProfileDialog(
            currentProfile = userProfile,
            onDismiss = { viewModel.setShowProfileModal(false) },
            onSave = { updated ->
                viewModel.updateUserProfile(updated)
                viewModel.setShowProfileModal(false)
            }
        )
    }

    if (showMemoryPanel) {
        MemoryPanelDialog(
            memories = memories,
            onDismiss = { viewModel.setShowMemoryPanel(false) },
            onAddMemory = { content, layer -> viewModel.addMemory(content, layer) },
            onDeleteMemory = { id -> viewModel.deleteMemory(id) },
            onClearAll = { viewModel.clearMemories() }
        )
    }
}

@Composable
fun ChatMessageItem(message: Message) {
    val isUser = message.role == "user"

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        Surface(
            color = if (isUser) FireOrange else MaterialTheme.colorScheme.surfaceVariant,
            contentColor = if (isUser) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (isUser) 16.dp else 4.dp,
                bottomEnd = if (isUser) 4.dp else 16.dp
            ),
            modifier = Modifier.widthIn(max = 320.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = message.content,
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = message.timestamp,
                    style = MaterialTheme.typography.bodySmall,
                    fontSize = 10.sp,
                    color = (if (isUser) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant).copy(alpha = 0.7f),
                    modifier = Modifier.align(Alignment.End)
                )
            }
        }

        if (!isUser && message.pcaState != null) {
            CognitiveOrchestrationCard(
                pcaState = message.pcaState,
                modifier = Modifier.widthIn(max = 340.dp)
            )
        }
    }
}
