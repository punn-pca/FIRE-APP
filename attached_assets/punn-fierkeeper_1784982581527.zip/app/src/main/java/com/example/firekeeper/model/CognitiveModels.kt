package com.example.firekeeper.model

enum class CognitiveStage(val stageNameTH: String, val stageNameEN: String, val stageNumber: Int) {
    OBSERVATION("1. การสังเกตการณ์", "Observation", 1),
    UNDERSTANDING("2. การทำความเข้าใจบริบท", "Understanding", 2),
    PURPOSE("3. การกำหนดเป้าหมาย", "Purpose", 3),
    MEMORY("4. การดึงข้อมูลอดีต", "Memory", 4),
    MENTAL_MODEL("5. แบบจำลองความคิด", "Mental Model", 5),
    HYPOTHESIS("6. การตั้งสมมติฐานทางเลือก", "Hypothesis", 6),
    EVIDENCE_EVALUATION("7. การประเมินหลักฐาน", "Evidence Evaluation", 7),
    CRITIQUE("8. การวิพากษ์ความเอนเอียง", "Critique", 8),
    DECISION("9. ข้อสรุปเชิงยุทธศาสตร์และแนวทางที่แนะนำ", "Strategic Conclusion", 9),
    COMMUNICATION("10. การสร้างคำตอบให้มนุษย์", "Communication", 10),
    REFLECTION("11. การสะท้อนคิด", "Reflection", 11),
    LEARNING("12. การเรียนรู้บันทึกความจำ", "Learning", 12)
}

enum class MemoryLayer(val label: String) {
    WORKING("working"),
    SESSION("session"),
    PROJECT("project"),
    SEMANTIC("semantic"),
    PROCEDURAL("procedural"),
    REFLECTIVE("reflective")
}

data class MemoryItem(
    val id: String,
    val content: String,
    val layer: MemoryLayer,
    val source: String,
    val confidence: Double = 0.75,
    val createdByStage: String = "Stage 12 (LEARNING)",
    val usedInConversations: List<String> = emptyList(),
    val createdAt: String = System.currentTimeMillis().toString()
)

enum class NodeType {
    PROBLEM, ASSUMPTION, EVIDENCE, COUNTER_EVIDENCE, CONSTRAINT, DECISION
}

data class GraphNode(
    val id: String,
    val type: NodeType,
    val label: String,
    val details: String = "",
    val confidence: Double = 0.8
)

data class GraphEdge(
    val from: String,
    val to: String,
    val label: String = "",
    val relationship: String = "supports"
)

data class ReasoningGraph(
    val nodes: List<GraphNode> = emptyList(),
    val edges: List<GraphEdge> = emptyList()
)

data class StrategyOption(
    val name: String,
    val status: String, // "selected", "rejected", "partially_used"
    val pros: String,
    val cons: String,
    val rejectionReason: String? = null
)

data class StrategySelection(
    val chosenStrategy: String,
    val rationale: String,
    val consideredStrategies: List<StrategyOption> = emptyList()
)

data class MemoryTrace(
    val memoryId: String,
    val createdByStage: String,
    val usedInConversations: List<String>,
    val confidenceFrom: Double,
    val confidenceTo: Double,
    val content: String,
    val layer: String = "project"
)

data class CognitiveTraceEntry(
    val stage: CognitiveStage,
    val timestamp: String,
    val summary: String
)

data class CognitiveState(
    val userInput: String,
    val observations: List<String> = emptyList(),
    val understanding: String = "",
    val purpose: String = "",
    val memories: List<MemoryItem> = emptyList(),
    val mentalModel: String = "",
    val hypotheses: List<String> = emptyList(),
    val evaluation: String = "",
    val confidence: Double = 0.75,
    val critique: List<String> = emptyList(),
    val decision: String = "",
    val responseText: String = "",
    val reflection: List<String> = emptyList(),
    val learningNotes: List<String> = emptyList(),
    val traces: List<CognitiveTraceEntry> = emptyList(),
    val reasoningGraph: ReasoningGraph? = null,
    val strategySelection: StrategySelection? = null,
    val memoryTraces: List<MemoryTrace> = emptyList()
)

data class Message(
    val id: String,
    val role: String, // "user" or "assistant"
    val content: String,
    val timestamp: String,
    val pcaState: CognitiveState? = null
)

data class ChatSession(
    val id: String,
    val title: String,
    val messages: List<Message> = emptyList(),
    val createdAt: String = System.currentTimeMillis().toString()
)

data class QuestionnaireData(
    val domain: String = "",
    val context: String = "",
    val decisionFactors: String = "",
    val constraints: String = ""
)

data class UserProfile(
    val name: String = "Cognitive Architect",
    val email: String = "architect@firekeeper.pca",
    val tone: String = "Formal Architect", // "Formal Architect", "Empathetic Guide", "Direct Strategist"
    val deepReasoning: Boolean = true,
    val personalContext: String = ""
)
