package com.example.firekeeper.ui.dialogs

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.firekeeper.model.UserProfile

@Composable
fun UserProfileDialog(
    currentProfile: UserProfile,
    onDismiss: () -> Unit,
    onSave: (UserProfile) -> Unit
) {
    var name by remember { mutableStateOf(currentProfile.name) }
    var tone by remember { mutableStateOf(currentProfile.tone) }
    var personalContext by remember { mutableStateOf(currentProfile.personalContext) }

    val toneOptions = listOf("Formal Architect", "Empathetic Guide", "Direct Strategist")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "ตั้งค่าบุคลิกภาพและบริบทระบบ (PCA Profile)",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("ชื่อผู้ใช้งาน / บทบาท") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("profile_name_input")
                )

                Text(
                    text = "น้ำเสียงและบุคลิกภาพการวิเคราะห์ (Cognitive Tone):",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Medium
                )

                toneOptions.forEach { option ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Start
                    ) {
                        RadioButton(
                            selected = (tone == option),
                            onClick = { tone = option },
                            modifier = Modifier.testTag("tone_option_$option")
                        )
                        Text(
                            text = option,
                            modifier = Modifier.padding(start = 8.dp),
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }

                OutlinedTextField(
                    value = personalContext,
                    onValueChange = { personalContext = it },
                    label = { Text("บริบทเฉพาะตัวของผู้ใช้งาน (Personal Context)") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("profile_personal_context_input"),
                    minLines = 2
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(
                        currentProfile.copy(
                            name = name,
                            tone = tone,
                            personalContext = personalContext
                        )
                    )
                },
                modifier = Modifier.testTag("save_profile_button")
            ) {
                Text("บันทึกการตั้งค่า")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("cancel_profile_button")
            ) {
                Text("ปิด")
            }
        }
    )
}
